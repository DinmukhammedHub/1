import React, { useState, useEffect } from 'react';

interface BreakScreenProps {
  onResumeTest: () => void;
  studentName?: string;
}

export const BreakScreen: React.FC<BreakScreenProps> = ({ 
  onResumeTest,
  studentName = 'Dinmukhammed Sattar'
}) => {
  // 10 minutes break countdown (600s) matching official Digital SAT Bluebook test day
  const [breakTimeRemaining, setBreakTimeRemaining] = useState(600);

  useEffect(() => {
    const timer = setInterval(() => {
      setBreakTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const minutes = Math.floor(breakTimeRemaining / 60);
  const seconds = breakTimeRemaining % 60;
  const formattedTime = `${minutes}:${String(seconds).padStart(2, '0')}`;

  return (
    <div className="h-screen w-screen bg-[#1c1c1c] text-white flex flex-col justify-between p-8 sm:p-12 select-none relative overflow-hidden font-sans">
      {/* Top Bar: 100% Battery matching Image 1 */}
      <div className="w-full flex justify-end items-center">
        <div className="flex items-center gap-1.5 text-xs text-white/90">
          <span className="font-semibold text-[13px]">100%</span>
          {/* Battery Icon with charging lightning bolt */}
          <div className="w-[24px] h-[12px] border border-white/80 rounded-[2.5px] p-[1px] flex items-center relative">
            <div className="h-full bg-white rounded-[1px] w-full" />
            <svg 
              className="w-2.5 h-2.5 text-black absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" 
              viewBox="0 0 24 24" 
              fill="currentColor"
            >
              <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
            </svg>
            <div className="w-[1.5px] h-[4px] bg-white absolute -right-[2.5px] top-[3px] rounded-r-[1px]" />
          </div>
        </div>
      </div>

      {/* Main Content Area: 2 Columns matching Image 1 */}
      <div className="flex-1 flex flex-col md:flex-row items-center justify-center gap-12 lg:gap-24 max-w-6xl mx-auto w-full py-4">
        {/* Left Column: Remaining Break Time card & Resume Testing button */}
        <div className="flex flex-col items-center justify-center min-w-[280px]">
          {/* Remaining Break Time Box with thin white/grey border */}
          <div className="border border-white/40 rounded-xl px-8 py-5 text-center w-[250px] shadow-sm">
            <div className="text-[15px] font-normal text-white/90 mb-1">
              Remaining Break Time:
            </div>
            <div className="text-[52px] font-bold text-white tracking-tight leading-none font-sans">
              {formattedTime}
            </div>
          </div>

          {/* Yellow Pill Button: Resume Testing */}
          <button
            onClick={onResumeTest}
            className="mt-6 px-8 py-2.5 rounded-full bg-[#fcd535] hover:bg-[#eac428] text-black font-bold text-[14px] transition-all transform active:scale-95 shadow-md cursor-pointer"
          >
            Resume Testing
          </button>
        </div>

        {/* Right Column: Official Break Rules matching Bluebook Test Day */}
        <div className="max-w-xl text-left">
          {/* Header 1 */}
          <h1 className="text-[28px] font-bold text-white mb-3 tracking-tight">
            Take a Break: Do Not Close Your Device
          </h1>

          <p className="text-[14px] text-white/90 leading-relaxed mb-4 font-normal">
            After the break, click <span className="font-bold text-white">Resume Testing</span> and you’ll start the next section. You can also resume whenever you are ready.
          </p>

          {/* Divider */}
          <div className="border-t border-white/20 my-5 max-w-lg" />

          <div className="text-[14px] font-bold text-white mb-3">
            Follow these rules during the break:
          </div>

          {/* Rules List */}
          <ol className="space-y-2.5 text-[14px] text-white/90 pl-1 leading-relaxed">
            <li className="flex items-start gap-2">
              <span className="font-semibold shrink-0">1.</span>
              <span>Do not disturb students who are still testing.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="font-semibold shrink-0">2.</span>
              <span>Do not exit the app or close your laptop.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="font-semibold shrink-0">3.</span>
              <span>Do not access phones, smartwatches, textbooks, notes, or the internet.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="font-semibold shrink-0">4.</span>
              <span>Do not eat or drink near any testing device.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="font-semibold shrink-0">5.</span>
              <span>Do not speak in the testing room; outside the room, do not discuss the exam with anyone.</span>
            </li>
          </ol>
        </div>
      </div>

      {/* Bottom Bar: Student Name on bottom-left matching Image 1 */}
      <div className="w-full flex items-center justify-between pt-4">
        <div className="text-[16px] font-bold text-white font-sans tracking-tight">
          {studentName}
        </div>
      </div>
    </div>
  );
};
