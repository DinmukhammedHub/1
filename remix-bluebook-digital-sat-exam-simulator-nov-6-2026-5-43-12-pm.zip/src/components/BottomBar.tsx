import React, { useState } from 'react';
import { Check } from 'lucide-react';

interface BottomBarProps {
  currentQuestionIndex: number;
  totalQuestions: number;
  studentName: string;
  onUpdateStudentName: (name: string) => void;
  onPrevQuestion: () => void;
  onNextQuestion: () => void;
  onOpenReviewGrid: () => void;
  isLastQuestion: boolean;
}

export const BottomBar: React.FC<BottomBarProps> = ({
  currentQuestionIndex,
  totalQuestions,
  studentName,
  onUpdateStudentName,
  onPrevQuestion,
  onNextQuestion,
  onOpenReviewGrid,
  isLastQuestion,
}) => {
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(studentName);

  const handleNameSave = () => {
    if (tempName.trim()) {
      onUpdateStudentName(tempName.trim());
    }
    setIsEditingName(false);
  };

  return (
    <div className="w-full bg-[#f8fafc] select-none z-30">
      {/* Пунктирный разделитель над футером */}
      <div
        style={{ borderBottom: '2px dashed #333333' }}
        className="w-full shrink-0"
      />

      {/* Нижняя панель (Footer) */}
      <footer className="h-[60px] px-7 bg-[#f8fafc] flex items-center justify-between">
        {/* Слева: Имя "Dinmukhammed Sattar" (шрифт sans-serif, medium) */}
        <div className="flex items-center min-w-[240px]">
          {isEditingName ? (
            <div className="flex items-center gap-1.5">
              <input
                type="text"
                value={tempName}
                onChange={(e) => setTempName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleNameSave();
                  if (e.key === 'Escape') setIsEditingName(false);
                }}
                autoFocus
                className="px-2 py-0.5 text-[15px] font-medium text-[#111111] border border-blue-500 rounded bg-white outline-none"
              />
              <button
                type="button"
                onClick={handleNameSave}
                className="p-1 hover:bg-slate-200 rounded text-emerald-600 cursor-pointer"
              >
                <Check className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div
              onClick={() => setIsEditingName(true)}
              style={{
                fontFamily: 'system-ui, -apple-system, sans-serif',
                fontWeight: 500,
                color: '#111111',
                fontSize: '15px',
              }}
              className="cursor-pointer hover:opacity-80 transition-opacity"
              title="Click to edit name"
            >
              {studentName}
            </div>
          )}
        </div>

        {/* По центру черная кнопка со скругленными краями: Текст "Question X of 27"
            Справа от текста белая иконка стрелки (chevron), указывающей ВВЕРХ (^) */}
        <div className="flex items-center justify-center">
          <button
            type="button"
            onClick={onOpenReviewGrid}
            style={{
              backgroundColor: '#111111',
              borderRadius: '6px',
              fontFamily: 'system-ui, -apple-system, sans-serif',
            }}
            className="flex items-center gap-2.5 px-4 h-[36px] text-[14px] font-medium text-white hover:bg-[#222222] transition-all cursor-pointer shadow-xs active:scale-95 leading-none"
            title="Question Review Navigator"
          >
            <span>Question {currentQuestionIndex + 1} of {totalQuestions}</span>
            {/* Белая стрелка (chevron) указывающая ВВЕРХ (^) */}
            <svg
              className="w-3.5 h-3.5 stroke-[2.4] text-white"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
            >
              <path d="M18 15l-6-6-6 6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>

        {/* Справа: Синяя кнопка "Next" (border-radius: 20px, padding: 8px 24px) */}
        <div className="flex items-center gap-3 min-w-[240px] justify-end">
          {currentQuestionIndex > 0 && (
            <button
              type="button"
              onClick={onPrevQuestion}
              style={{
                borderRadius: '20px',
                padding: '8px 24px',
                fontFamily: 'system-ui, -apple-system, sans-serif',
              }}
              className="text-[14px] font-medium bg-[#1d3a8a] hover:bg-[#162e6e] text-white transition-all cursor-pointer shadow-xs active:scale-95 flex items-center justify-center leading-none"
            >
              Back
            </button>
          )}

          <button
            type="button"
            onClick={onNextQuestion}
            style={{
              borderRadius: '20px',
              padding: '8px 24px',
              fontFamily: 'system-ui, -apple-system, sans-serif',
            }}
            className="text-[14px] font-medium bg-[#1d3a8a] hover:bg-[#162e6e] text-white transition-all cursor-pointer shadow-xs active:scale-95 flex items-center justify-center leading-none"
          >
            {isLastQuestion ? 'Review' : 'Next'}
          </button>
        </div>
      </footer>
    </div>
  );
};
