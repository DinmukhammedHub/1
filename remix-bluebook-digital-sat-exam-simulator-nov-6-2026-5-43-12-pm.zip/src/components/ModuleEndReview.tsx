import React from 'react';
import { QuestionState } from '../types/sat';

interface ModuleEndReviewProps {
  moduleTitle: string;
  totalQuestions: number;
  currentQuestionIndex: number;
  questionStates: Record<number, QuestionState>;
  onSelectQuestion: (index: number) => void;
  onSubmitModule: () => void;
  onBackToCurrentQuestion: () => void;
  studentName: string;
}

export const ModuleEndReview: React.FC<ModuleEndReviewProps> = ({
  moduleTitle,
  totalQuestions,
  currentQuestionIndex,
  questionStates,
  onSelectQuestion,
  onSubmitModule,
  onBackToCurrentQuestion,
  studentName,
}) => {
  const isAnswered = (index: number) => {
    const state = questionStates[index];
    return Boolean(state?.selectedOption || (state?.sprValue && state.sprValue.trim().length > 0));
  };

  const isMarked = (index: number) => {
    return Boolean(questionStates[index]?.isMarkedForReview);
  };

  const questionIndices = Array.from({ length: totalQuestions }, (_, i) => i);

  return (
    <div className="h-full w-full bg-[#f8fafc] flex flex-col justify-between select-none overflow-y-auto">
      {/* Main Review Centerpiece */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-8 max-w-4xl mx-auto w-full">
        {/* Title: Check Your Work */}
        <h1 className="text-[32px] font-bold text-[#111827] mb-4 text-center tracking-tight font-sans">
          Check Your Work
        </h1>

        {/* Informative Subtext */}
        <p className="text-[15px] text-[#111827] text-center max-w-2xl mx-auto leading-relaxed mb-1 font-sans">
          You may return to any question in this module until time expires.
        </p>
        <p className="text-[15px] text-[#111827] text-center max-w-2xl mx-auto leading-relaxed mb-8 font-sans">
          When you are ready, click <span className="font-bold">Next</span> to proceed.
        </p>

        {/* Center Card matching Image 2 & 4 */}
        <div className="w-full max-w-[620px] bg-white rounded-2xl shadow-sm border border-slate-200/90 p-7">
          {/* Card Header: Title on Left, Legend on Right */}
          <div className="flex items-center justify-between pb-3.5 border-b border-slate-200 gap-4">
            <h3 className="font-bold text-[16px] text-[#111827] font-sans tracking-tight">
              {moduleTitle} Questions
            </h3>

            {/* Legend: Unanswered & For Review */}
            <div className="flex items-center gap-4 text-[13px] font-medium text-[#111827]">
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 border border-dashed border-[#111827] inline-block rounded-[1px] bg-white" />
                <span>Unanswered</span>
              </div>
              <div className="flex items-center gap-1.5">
                <svg className="w-3.5 h-4.5 text-[#d92d20] fill-[#d92d20]" viewBox="0 0 24 24">
                  <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
                </svg>
                <span>For Review</span>
              </div>
            </div>
          </div>

          {/* 10-column Grid matching Image 2 & 4 */}
          <div className="grid grid-cols-10 gap-x-2 gap-y-3.5 pt-6 px-1 justify-items-center">
            {questionIndices.map((idx) => {
              const questionNum = idx + 1;
              const isCurrent = currentQuestionIndex === idx;
              const answered = isAnswered(idx);
              const marked = isMarked(idx);

              return (
                <div key={idx} className="relative flex flex-col items-center">
                  <button
                    onClick={() => onSelectQuestion(idx)}
                    className={`w-[32px] h-[32px] rounded-[1px] flex items-center justify-center font-bold text-[16px] font-sans transition-all cursor-pointer relative select-none ${
                      isCurrent
                        ? 'bg-[#2b50aa] text-white border border-[#2b50aa] shadow-xs'
                        : answered
                        ? 'bg-slate-100 border border-slate-700 text-[#2b49b3] hover:bg-slate-200'
                        : 'bg-white border border-dashed border-[#111827] text-[#2b49b3] hover:bg-slate-50'
                    }`}
                    title={`Question ${questionNum}${isCurrent ? ' (Current)' : ''}${answered ? ' (Answered)' : ' (Unanswered)'}${marked ? ' (Marked for review)' : ''}`}
                  >
                    {/* Red bookmark ribbon if marked */}
                    {marked && (
                      <div className="absolute -top-1 -right-1 z-10">
                        <svg className="w-3 h-3 text-[#d92d20] fill-[#d92d20] drop-shadow-xs" viewBox="0 0 24 24">
                          <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
                        </svg>
                      </div>
                    )}
                    <span>{questionNum}</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Bottom Bar on Check Your Work page matching Image 2 */}
      <div className="w-full bg-[#e8eef7] select-none">
        <div className="bluebook-dashed-line" />
        <footer className="h-[58px] px-8 bg-[#e8eef7] flex items-center justify-between">
          {/* Candidate Name on Left */}
          <div className="text-[#111827] font-bold text-[17px] tracking-tight font-sans">
            {studentName}
          </div>

          {/* Right Action Buttons: Back and Next matching Image 2 */}
          <div className="flex items-center gap-3">
            <button
              onClick={onBackToCurrentQuestion}
              className="h-[36px] px-7 text-[14px] font-bold rounded-full bg-[#2554d7] hover:bg-[#1d46b8] text-white transition-all cursor-pointer shadow-sm active:scale-95 flex items-center justify-center leading-none"
            >
              Back
            </button>
            <button
              onClick={onSubmitModule}
              className="h-[36px] px-7 text-[14px] font-bold rounded-full bg-[#2554d7] hover:bg-[#1d46b8] text-white transition-all cursor-pointer shadow-sm active:scale-95 flex items-center justify-center leading-none"
            >
              Next
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
};
