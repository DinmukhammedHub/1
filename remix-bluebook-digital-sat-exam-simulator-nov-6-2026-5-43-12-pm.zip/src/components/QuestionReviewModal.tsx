import React from 'react';
import { QuestionState } from '../types/sat';

interface QuestionReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  totalQuestions: number;
  currentQuestionIndex: number;
  questionStates: Record<number, QuestionState>;
  onSelectQuestion: (index: number) => void;
  onGoToReviewPage: () => void;
  sectionTitle: string;
}

export const QuestionReviewModal: React.FC<QuestionReviewModalProps> = ({
  isOpen,
  onClose,
  totalQuestions,
  currentQuestionIndex,
  questionStates,
  onSelectQuestion,
  onGoToReviewPage,
  sectionTitle,
}) => {
  if (!isOpen) return null;

  const isAnswered = (index: number) => {
    const state = questionStates[index];
    return Boolean(state?.selectedOption || (state?.sprValue && state.sprValue.trim().length > 0));
  };

  const isMarked = (index: number) => {
    return Boolean(questionStates[index]?.isMarkedForReview);
  };

  const questionIndices = Array.from({ length: totalQuestions }, (_, i) => i);

  return (
    <div className="fixed inset-0 z-50 select-none animate-in fade-in-50">
      {/* Click-away backdrop */}
      <div 
        className="fixed inset-0 bg-black/5" 
        onClick={onClose} 
      />

      {/* Popover anchored directly above the bottom Question Review button */}
      <div className="absolute bottom-[66px] left-1/2 -translate-x-1/2 w-[430px] max-w-[94vw] bg-white rounded-2xl shadow-2xl border border-slate-200/90 p-6 z-10">
        {/* Downwards pointer triangle pointing exactly to the bottom "Question X of Y" button */}
        <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-white border-r border-b border-slate-200/90 transform rotate-45 shadow-xs" />

        {/* Close Button top-right */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 text-slate-400 hover:text-slate-800 transition-colors cursor-pointer rounded-full"
          title="Close"
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>

        {/* Header Title: 2 lines centered matching Image 1 & 3 */}
        <div className="text-center pt-0.5 px-4">
          <h2 className="text-[17px] font-bold text-[#111827] leading-tight font-sans">
            {sectionTitle}
          </h2>
          <div className="text-[17px] font-bold text-[#111827] leading-tight font-sans">
            Questions
          </div>
        </div>

        {/* Separator line */}
        <div className="border-t border-slate-200 my-3.5" />

        {/* Legend: Current (pin), Unanswered (dashed), For Review (red ribbon) */}
        <div className="flex items-center justify-center gap-5 text-[13px] font-medium text-[#111827]">
          {/* Current Legend */}
          <div className="flex items-center gap-1.5">
            <svg className="w-4 h-4 text-black" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
              <path d="M12 2a6 6 0 0 0-6 6c0 4.5 6 12 6 12s6-7.5 6-12a6 6 0 0 0-6-6z" fill="none" stroke="currentColor" />
              <circle cx="12" cy="8" r="2" fill="none" stroke="currentColor" />
            </svg>
            <span>Current</span>
          </div>

          {/* Unanswered Legend */}
          <div className="flex items-center gap-1.5">
            <span className="w-4 h-4 border border-dashed border-[#111827] inline-block rounded-[1px] bg-white" />
            <span>Unanswered</span>
          </div>

          {/* For Review Legend */}
          <div className="flex items-center gap-1.5">
            <svg className="w-3.5 h-4.5 text-[#d92d20] fill-[#d92d20]" viewBox="0 0 24 24">
              <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
            </svg>
            <span>For Review</span>
          </div>
        </div>

        {/* Exactly 10-column Question Numbers Grid matching Image 1 & 3 */}
        <div className="grid grid-cols-10 gap-x-2 gap-y-3.5 mt-5 px-1 justify-items-center">
          {questionIndices.map((idx) => {
            const questionNum = idx + 1;
            const isCurrent = currentQuestionIndex === idx;
            const answered = isAnswered(idx);
            const marked = isMarked(idx);

            return (
              <div key={idx} className="relative flex flex-col items-center">
                {/* Black Location Pin icon directly above Current question box */}
                {isCurrent && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 pointer-events-none">
                    <svg className="w-3.5 h-3.5 text-black" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <path d="M12 2a6 6 0 0 0-6 6c0 4.5 6 12 6 12s6-7.5 6-12a6 6 0 0 0-6-6z" fill="none" stroke="currentColor" />
                      <circle cx="12" cy="8" r="2" fill="none" stroke="currentColor" />
                    </svg>
                  </div>
                )}

                {/* Number Box */}
                <button
                  onClick={() => {
                    onSelectQuestion(idx);
                    onClose();
                  }}
                  className={`w-[29px] h-[29px] rounded-[1px] flex items-center justify-center font-bold text-[15px] font-sans transition-all cursor-pointer relative select-none ${
                    isCurrent
                      ? 'bg-[#2b50aa] text-white border border-[#2b50aa] shadow-xs underline decoration-white decoration-2 underline-offset-2'
                      : answered
                      ? 'bg-slate-100 border border-slate-700 text-[#2b49b3] hover:bg-slate-200'
                      : 'bg-white border border-dashed border-[#111827] text-[#2b49b3] hover:bg-slate-50'
                  }`}
                  title={`Question ${questionNum}${isCurrent ? ' (Current)' : ''}${answered ? ' (Answered)' : ' (Unanswered)'}${marked ? ' (Marked for review)' : ''}`}
                >
                  {/* Red Bookmark Ribbon Flag for Marked questions */}
                  {marked && (
                    <div className="absolute -top-1 -right-1 z-10">
                      <svg className="w-3 h-3 text-[#d92d20] fill-[#d92d20] drop-shadow-xs" viewBox="0 0 24 24">
                        <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
                      </svg>
                    </div>
                  )}
                  <span>{questionNum}</span>
                </button>
              </div>
            );
          })}
        </div>

        {/* Go to Review Page Button matching Image 1 & 3 */}
        <div className="flex justify-center mt-6 mb-1">
          <button
            onClick={() => {
              onGoToReviewPage();
              onClose();
            }}
            className="px-8 py-1.5 rounded-full border-[1.5px] border-[#2554d7] text-[#2554d7] hover:bg-blue-50/80 font-bold text-[14px] transition-colors cursor-pointer active:scale-95 shadow-xs"
          >
            Go to Review Page
          </button>
        </div>
      </div>
    </div>
  );
};
