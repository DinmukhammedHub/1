import React, { useState } from 'react';
import { X, Award, CheckCircle2, XCircle, RotateCcw, ChevronDown, ChevronUp } from 'lucide-react';
import { Question, QuestionState } from '../types/sat';

interface ScoreReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  rw1Questions: Question[];
  rw1States: Record<number, QuestionState>;
  rw2Questions: Question[];
  rw2States: Record<number, QuestionState>;
  math1Questions: Question[];
  math1States: Record<number, QuestionState>;
  math2Questions: Question[];
  math2States: Record<number, QuestionState>;
  onResetTest: () => void;
  studentName: string;
}

export const ScoreReportModal: React.FC<ScoreReportModalProps> = ({
  isOpen,
  onClose,
  rw1Questions,
  rw1States,
  rw2Questions,
  rw2States,
  math1Questions,
  math1States,
  math2Questions,
  math2States,
  onResetTest,
  studentName,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'rw1' | 'rw2' | 'math1' | 'math2'>('all');
  const [expandedQuestion, setExpandedQuestion] = useState<string | null>(null);

  if (!isOpen) return null;

  const countCorrect = (questions: Question[], states: Record<number, QuestionState>) => {
    let correct = 0;
    questions.forEach((q, idx) => {
      const state = states[idx];
      if (q.isSPR) {
        const val = state?.sprValue?.trim();
        if (val && (val === q.correctAnswer || q.acceptedAnswers?.includes(val))) {
          correct++;
        }
      } else {
        if (state?.selectedOption === q.correctAnswer) {
          correct++;
        }
      }
    });
    return correct;
  };

  const rw1Correct = countCorrect(rw1Questions, rw1States);
  const rw2Correct = countCorrect(rw2Questions, rw2States);
  const totalRwCorrect = rw1Correct + rw2Correct;
  const totalRwQuestions = rw1Questions.length + rw2Questions.length;

  const math1Correct = countCorrect(math1Questions, math1States);
  const math2Correct = countCorrect(math2Questions, math2States);
  const totalMathCorrect = math1Correct + math2Correct;
  const totalMathQuestions = math1Questions.length + math2Questions.length;

  // Digital SAT Scaled scoring with Hard Module curve:
  // RW: 54 questions total.
  const rwScaled = Math.round(200 + (totalRwCorrect / Math.max(1, totalRwQuestions)) * 600);
  // Math: 44 questions total.
  const mathScaled = Math.round(200 + (totalMathCorrect / Math.max(1, totalMathQuestions)) * 600);
  const totalScore = rwScaled + mathScaled;

  const getModuleData = () => {
    switch (activeTab) {
      case 'rw1':
        return [{ title: 'Section 1, Module 1: Reading and Writing (Baseline)', questions: rw1Questions, states: rw1States, prefix: 'rw1' }];
      case 'rw2':
        return [{ title: 'Section 1, Module 2: Reading and Writing (Hard)', questions: rw2Questions, states: rw2States, prefix: 'rw2' }];
      case 'math1':
        return [{ title: 'Section 2, Module 1: Math (Baseline)', questions: math1Questions, states: math1States, prefix: 'm1' }];
      case 'math2':
        return [{ title: 'Section 2, Module 2: Math (Hard)', questions: math2Questions, states: math2States, prefix: 'm2' }];
      case 'all':
      default:
        return [
          { title: 'Section 1, Module 1: Reading and Writing (Baseline)', questions: rw1Questions, states: rw1States, prefix: 'rw1' },
          { title: 'Section 1, Module 2: Reading and Writing (Hard)', questions: rw2Questions, states: rw2States, prefix: 'rw2' },
          { title: 'Section 2, Module 1: Math (Baseline)', questions: math1Questions, states: math1States, prefix: 'm1' },
          { title: 'Section 2, Module 2: Math (Hard)', questions: math2Questions, states: math2States, prefix: 'm2' },
        ];
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in-50">
      <div className="fixed inset-0" onClick={onClose} />
      <div className="relative w-full max-w-4xl bg-white rounded-xl shadow-2xl border border-slate-300 overflow-hidden z-10 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-[#002f6c] text-white">
          <div className="flex items-center gap-3">
            <Award className="w-6 h-6 text-yellow-400" />
            <div>
              <h3 className="text-lg font-bold">Official Digital SAT Score Report</h3>
              <p className="text-xs text-blue-100">Candidate: {studentName} • Hard Module Adaptive Form</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-white/20 rounded cursor-pointer">
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Score Summary */}
        <div className="p-6 bg-slate-50 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
          <div className="p-4 bg-white rounded-lg border border-slate-200 shadow-xs">
            <div className="text-3xl sm:text-4xl font-bold font-mono text-[#002f6c]">
              {totalScore}
            </div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mt-1">
              Total Score (400–1600)
            </div>
          </div>

          <div className="p-4 bg-white rounded-lg border border-slate-200 shadow-xs">
            <div className="text-2xl sm:text-3xl font-bold font-mono text-slate-800">
              {rwScaled}
            </div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mt-1">
              Reading and Writing ({totalRwCorrect}/{totalRwQuestions})
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              M1: {rw1Correct}/{rw1Questions.length} • M2 (Hard): {rw2Correct}/{rw2Questions.length}
            </div>
          </div>

          <div className="p-4 bg-white rounded-lg border border-slate-200 shadow-xs">
            <div className="text-2xl sm:text-3xl font-bold font-mono text-slate-800">
              {mathScaled}
            </div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mt-1">
              Math ({totalMathCorrect}/{totalMathQuestions})
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              M1: {math1Correct}/{math1Questions.length} • M2 (Hard): {math2Correct}/{math2Questions.length}
            </div>
          </div>
        </div>

        {/* Filter Navigation Tabs */}
        <div className="flex items-center gap-1.5 px-6 py-2.5 bg-slate-100 border-b border-slate-200 overflow-x-auto text-xs font-medium">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'all' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Questions (98)
          </button>
          <button
            onClick={() => setActiveTab('rw1')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'rw1' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            RW Module 1 (27)
          </button>
          <button
            onClick={() => setActiveTab('rw2')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'rw2' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            RW Module 2 [Hard] (27)
          </button>
          <button
            onClick={() => setActiveTab('math1')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'math1' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Math Module 1 (22)
          </button>
          <button
            onClick={() => setActiveTab('math2')}
            className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === 'math2' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Math Module 2 [Hard] (22)
          </button>
        </div>

        {/* Question Review List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {getModuleData().map((modGroup) => (
            <div key={modGroup.prefix} className="space-y-3">
              <h4 className="text-sm font-bold text-slate-800 border-b pb-1.5 flex items-center justify-between">
                <span>{modGroup.title}</span>
                <span className="text-xs font-normal text-slate-500">
                  {countCorrect(modGroup.questions, modGroup.states)} / {modGroup.questions.length} Correct
                </span>
              </h4>

              <div className="space-y-2.5">
                {modGroup.questions.map((q, idx) => {
                  const state = modGroup.states[idx];
                  const userAns = q.isSPR ? state?.sprValue?.trim() : state?.selectedOption;
                  const isCorrect = q.isSPR
                    ? userAns === q.correctAnswer || q.acceptedAnswers?.includes(userAns || '')
                    : userAns === q.correctAnswer;
                  const isAnswered = Boolean(userAns);
                  const itemKey = `${modGroup.prefix}-${idx}`;
                  const isExpanded = expandedQuestion === itemKey;

                  return (
                    <div
                      key={itemKey}
                      className={`border rounded-lg transition-all ${
                        isCorrect
                          ? 'border-emerald-200 bg-emerald-50/20'
                          : isAnswered
                          ? 'border-red-200 bg-red-50/20'
                          : 'border-slate-200 bg-slate-50/30'
                      }`}
                    >
                      <div
                        onClick={() => setExpandedQuestion(isExpanded ? null : itemKey)}
                        className="p-3.5 flex items-center justify-between cursor-pointer hover:bg-slate-50/80 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          {isCorrect ? (
                            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                          ) : isAnswered ? (
                            <XCircle className="w-5 h-5 text-red-600 shrink-0" />
                          ) : (
                            <span className="w-5 h-5 rounded-full border-2 border-dashed border-slate-400 inline-block shrink-0" />
                          )}
                          <div className="text-sm font-semibold text-slate-900">
                            Question {idx + 1}
                            <span className="text-xs font-normal text-slate-500 ml-2">
                              {q.domain} • {q.skill}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-4">
                          <div className="text-xs text-right">
                            <span className="text-slate-500 mr-1.5">Your answer:</span>
                            <span className={`font-mono font-bold ${isCorrect ? 'text-emerald-700' : isAnswered ? 'text-red-700' : 'text-slate-400'}`}>
                              {userAns || 'None'}
                            </span>
                            <span className="text-slate-400 mx-1.5">|</span>
                            <span className="text-slate-500 mr-1.5">Correct:</span>
                            <span className="font-mono font-bold text-slate-800">{q.correctAnswer}</span>
                          </div>
                          {isExpanded ? (
                            <ChevronUp className="w-4 h-4 text-slate-400" />
                          ) : (
                            <ChevronDown className="w-4 h-4 text-slate-400" />
                          )}
                        </div>
                      </div>

                      {isExpanded && (
                        <div className="px-5 py-4 border-t border-slate-200 bg-white space-y-3 text-xs leading-relaxed">
                          {q.passage && (
                            <div className="p-3 bg-slate-50 rounded border border-slate-200 text-slate-700 font-reading">
                              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                                Passage Stimulus
                              </span>
                              <div dangerouslySetInnerHTML={{ __html: q.passage }} />
                            </div>
                          )}

                          <div>
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                              Question Prompt
                            </span>
                            <div className="font-reading text-slate-900 font-medium" dangerouslySetInnerHTML={{ __html: q.questionText }} />
                          </div>

                          {q.options && (
                            <div className="space-y-1.5 pt-1">
                              {q.options.map((opt) => (
                                <div
                                  key={opt.id}
                                  className={`p-2 rounded border flex items-start gap-2 ${
                                    opt.id === q.correctAnswer
                                      ? 'bg-emerald-50 border-emerald-300 font-semibold text-emerald-900'
                                      : opt.id === userAns
                                      ? 'bg-red-50 border-red-300 text-red-900'
                                      : 'bg-white border-slate-200 text-slate-700'
                                  }`}
                                >
                                  <span className="w-5 h-5 rounded-full border border-current flex items-center justify-center font-bold text-[11px] shrink-0">
                                    {opt.id}
                                  </span>
                                  <span dangerouslySetInnerHTML={{ __html: opt.text }} />
                                </div>
                              ))}
                            </div>
                          )}

                          <div className="p-3 bg-blue-50/70 rounded-lg border border-blue-200 text-blue-950">
                            <span className="font-bold block mb-1">Explanation:</span>
                            <p>{q.explanation}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={onResetTest}
            className="flex items-center gap-2 px-4 py-2 border border-slate-300 rounded-lg text-sm font-semibold text-slate-700 hover:bg-white cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Retake Exam</span>
          </button>
          <button
            onClick={onClose}
            className="px-6 py-2 bg-[#002f6c] text-white rounded-lg text-sm font-semibold hover:bg-[#002352] cursor-pointer"
          >
            Close Report
          </button>
        </div>
      </div>
    </div>
  );
};
