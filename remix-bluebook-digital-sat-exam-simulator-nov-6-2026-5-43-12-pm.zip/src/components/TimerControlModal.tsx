import React, { useState } from 'react';
import { Play, Pause, RotateCcw, Clock, Plus, Minus, Check, X, Eye, EyeOff } from 'lucide-react';

interface TimerControlModalProps {
  isOpen: boolean;
  onClose: () => void;
  timeRemainingSeconds: number;
  isTimerRunning: boolean;
  onToggleTimerRunning: () => void;
  onSetTimeRemainingSeconds: (seconds: number) => void;
  isTimerHidden: boolean;
  onToggleTimerHidden: () => void;
  defaultModuleSeconds: number;
}

export const TimerControlModal: React.FC<TimerControlModalProps> = ({
  isOpen,
  onClose,
  timeRemainingSeconds,
  isTimerRunning,
  onToggleTimerRunning,
  onSetTimeRemainingSeconds,
  isTimerHidden,
  onToggleTimerHidden,
  defaultModuleSeconds,
}) => {
  const currentMinutes = Math.floor(timeRemainingSeconds / 60);
  const currentSeconds = timeRemainingSeconds % 60;

  const [inputMinutes, setInputMinutes] = useState(String(currentMinutes));
  const [inputSeconds, setInputSeconds] = useState(String(currentSeconds).padStart(2, '0'));

  if (!isOpen) return null;

  const handleApplyCustomTime = () => {
    const mins = Math.max(0, parseInt(inputMinutes, 10) || 0);
    const secs = Math.max(0, Math.min(59, parseInt(inputSeconds, 10) || 0));
    const total = mins * 60 + secs;
    onSetTimeRemainingSeconds(total);
  };

  const handleAddMinutes = (deltaMins: number) => {
    const newTotal = Math.max(0, timeRemainingSeconds + deltaMins * 60);
    onSetTimeRemainingSeconds(newTotal);
    setInputMinutes(String(Math.floor(newTotal / 60)));
    setInputSeconds(String(newTotal % 60).padStart(2, '0'));
  };

  const handleSetPreset = (presetSecs: number) => {
    onSetTimeRemainingSeconds(presetSecs);
    setInputMinutes(String(Math.floor(presetSecs / 60)));
    setInputSeconds(String(presetSecs % 60).padStart(2, '0'));
  };

  const formattedDisplay = `${String(currentMinutes).padStart(2, '0')}:${String(currentSeconds).padStart(2, '0')}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs select-none animate-in fade-in-50">
      <div className="fixed inset-0" onClick={onClose} />
      
      <div className="relative w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden z-10 p-5 font-sans">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2 text-slate-900 font-bold text-base">
            <Clock className="w-5 h-5 text-blue-700" />
            <span>Timer Controls</span>
          </div>
          <button 
            onClick={onClose} 
            className="p-1 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Time Display & Play/Pause */}
        <div className="my-5 text-center bg-slate-50 border border-slate-200 rounded-xl p-4">
          <div className="text-4xl font-mono font-bold text-slate-900 tracking-tight">
            {formattedDisplay}
          </div>
          
          <div className="mt-1 flex items-center justify-center gap-2">
            <span className={`inline-block w-2.5 h-2.5 rounded-full ${isTimerRunning ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
            <span className="text-xs font-semibold text-slate-600">
              {isTimerRunning ? 'Timer is running' : 'Timer is paused'}
            </span>
          </div>

          <div className="mt-4 flex items-center justify-center gap-3">
            <button
              onClick={onToggleTimerRunning}
              className={`flex items-center gap-2 px-5 py-2 rounded-lg font-bold text-sm shadow-sm transition-all cursor-pointer active:scale-95 ${
                isTimerRunning
                  ? 'bg-amber-500 hover:bg-amber-600 text-white'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white'
              }`}
            >
              {isTimerRunning ? (
                <>
                  <Pause className="w-4 h-4 fill-white" />
                  <span>Pause Timer</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-white" />
                  <span>Resume Timer</span>
                </>
              )}
            </button>

            <button
              onClick={onToggleTimerHidden}
              className="flex items-center gap-1.5 px-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-white cursor-pointer"
            >
              {isTimerHidden ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              <span>{isTimerHidden ? 'Show in TopBar' : 'Hide in TopBar'}</span>
            </button>
          </div>
        </div>

        {/* Quick Add/Subtract Buttons */}
        <div className="mb-4">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            Quick Adjust
          </div>
          <div className="grid grid-cols-4 gap-2 text-xs font-bold">
            <button
              onClick={() => handleAddMinutes(5)}
              className="py-1.5 px-2 bg-blue-50 text-blue-700 border border-blue-200 rounded-md hover:bg-blue-100 cursor-pointer flex items-center justify-center gap-0.5"
            >
              <Plus className="w-3 h-3" /> 5 min
            </button>
            <button
              onClick={() => handleAddMinutes(1)}
              className="py-1.5 px-2 bg-blue-50 text-blue-700 border border-blue-200 rounded-md hover:bg-blue-100 cursor-pointer flex items-center justify-center gap-0.5"
            >
              <Plus className="w-3 h-3" /> 1 min
            </button>
            <button
              onClick={() => handleAddMinutes(-1)}
              className="py-1.5 px-2 bg-slate-100 text-slate-700 border border-slate-200 rounded-md hover:bg-slate-200 cursor-pointer flex items-center justify-center gap-0.5"
            >
              <Minus className="w-3 h-3" /> 1 min
            </button>
            <button
              onClick={() => handleAddMinutes(-5)}
              className="py-1.5 px-2 bg-slate-100 text-slate-700 border border-slate-200 rounded-md hover:bg-slate-200 cursor-pointer flex items-center justify-center gap-0.5"
            >
              <Minus className="w-3 h-3" /> 5 min
            </button>
          </div>
        </div>

        {/* Presets */}
        <div className="mb-4">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            Exam Presets
          </div>
          <div className="grid grid-cols-3 gap-2 text-xs font-semibold">
            <button
              onClick={() => handleSetPreset(1920)}
              className="py-1.5 px-2 border border-slate-300 rounded-md text-slate-800 hover:bg-slate-50 cursor-pointer"
            >
              32:00 (RW)
            </button>
            <button
              onClick={() => handleSetPreset(2100)}
              className="py-1.5 px-2 border border-slate-300 rounded-md text-slate-800 hover:bg-slate-50 cursor-pointer"
            >
              35:00 (Math)
            </button>
            <button
              onClick={() => handleSetPreset(705)}
              className="py-1.5 px-2 border border-slate-300 rounded-md text-slate-800 hover:bg-slate-50 cursor-pointer"
            >
              11:45 (Photo)
            </button>
            <button
              onClick={() => handleSetPreset(340)}
              className="py-1.5 px-2 border border-slate-300 rounded-md text-slate-800 hover:bg-slate-50 cursor-pointer"
            >
              5:40 (Review)
            </button>
            <button
              onClick={() => handleSetPreset(60)}
              className="py-1.5 px-2 border border-slate-300 rounded-md text-slate-800 hover:bg-slate-50 cursor-pointer"
            >
              1:00 (Test)
            </button>
            <button
              onClick={() => handleSetPreset(defaultModuleSeconds)}
              className="py-1.5 px-2 bg-slate-900 text-white rounded-md hover:bg-slate-800 cursor-pointer flex items-center justify-center gap-1"
            >
              <RotateCcw className="w-3 h-3" /> Reset
            </button>
          </div>
        </div>

        {/* Set Custom Time */}
        <div className="pt-3 border-t border-slate-200">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            Set Exact Minutes & Seconds
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 flex-1">
              <input
                type="number"
                min="0"
                max="99"
                value={inputMinutes}
                onChange={(e) => setInputMinutes(e.target.value)}
                placeholder="MM"
                className="w-full text-center py-1.5 px-2 border border-slate-300 rounded-md font-mono text-sm font-bold text-slate-900 focus:border-blue-600 outline-none"
              />
              <span className="font-bold text-slate-400">:</span>
              <input
                type="number"
                min="0"
                max="59"
                value={inputSeconds}
                onChange={(e) => setInputSeconds(e.target.value)}
                placeholder="SS"
                className="w-full text-center py-1.5 px-2 border border-slate-300 rounded-md font-mono text-sm font-bold text-slate-900 focus:border-blue-600 outline-none"
              />
            </div>

            <button
              onClick={handleApplyCustomTime}
              className="px-4 py-1.5 bg-[#2554d7] hover:bg-[#1d46b8] text-white rounded-md text-xs font-bold cursor-pointer transition-colors"
            >
              Set
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
