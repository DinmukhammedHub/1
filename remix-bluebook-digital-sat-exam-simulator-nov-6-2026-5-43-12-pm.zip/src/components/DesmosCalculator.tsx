import React, { useState, useRef, useEffect } from 'react';
import { X, Delete, ArrowRight } from 'lucide-react';

interface DesmosCalculatorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DesmosCalculator: React.FC<DesmosCalculatorProps> = ({ isOpen, onClose }) => {
  const [expression, setExpression] = useState('');
  const [result, setResult] = useState('');
  const [mode, setMode] = useState<'calc' | 'graph'>('calc');
  const [graphFn, setGraphFn] = useState('x^2 - 4');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const append = (char: string) => {
    setExpression((prev) => prev + char);
  };

  const clearAll = () => {
    setExpression('');
    setResult('');
  };

  const backspace = () => {
    setExpression((prev) => prev.slice(0, -1));
  };

  const evaluate = () => {
    try {
      // Safe mathematical evaluation
      const sanitized = expression
        .replace(/π/g, 'Math.PI')
        .replace(/e/g, 'Math.E')
        .replace(/sin\(/g, 'Math.sin(')
        .replace(/cos\(/g, 'Math.cos(')
        .replace(/tan\(/g, 'Math.tan(')
        .replace(/sqrt\(/g, 'Math.sqrt(')
        .replace(/log\(/g, 'Math.log10(')
        .replace(/ln\(/g, 'Math.log(')
        .replace(/\^/g, '**');

      // eslint-disable-next-line no-eval
      const res = Function(`"use strict"; return (${sanitized})`)();
      if (typeof res === 'number') {
        setResult(Number.isInteger(res) ? String(res) : res.toFixed(6).replace(/\.?0+$/, ''));
      } else {
        setResult('Error');
      }
    } catch {
      setResult('Syntax Error');
    }
  };

  // Render graph on canvas
  useEffect(() => {
    if (mode !== 'graph' || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    // Grid lines
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    const scale = 24; // 24px per unit
    const originX = width / 2;
    const originY = height / 2;

    for (let x = originX % scale; x < width; x += scale) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = originY % scale; y < height; y += scale) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Axes
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, originY);
    ctx.lineTo(width, originY);
    ctx.moveTo(originX, 0);
    ctx.lineTo(originX, height);
    ctx.stroke();

    // Plot graphFn
    try {
      const sanitized = graphFn
        .replace(/sin/g, 'Math.sin')
        .replace(/cos/g, 'Math.cos')
        .replace(/tan/g, 'Math.tan')
        .replace(/sqrt/g, 'Math.sqrt')
        .replace(/\^/g, '**');

      const fn = new Function('x', `"use strict"; return (${sanitized})`);

      ctx.strokeStyle = '#2563eb';
      ctx.lineWidth = 2.5;
      ctx.beginPath();

      let started = false;
      for (let px = 0; px < width; px += 2) {
        const x = (px - originX) / scale;
        try {
          const y = fn(x);
          const py = originY - y * scale;
          if (Number.isFinite(py) && py >= -100 && py <= height + 100) {
            if (!started) {
              ctx.moveTo(px, py);
              started = true;
            } else {
              ctx.lineTo(px, py);
            }
          } else {
            started = false;
          }
        } catch {
          started = false;
        }
      }
      ctx.stroke();
    } catch {
      // invalid fn
    }
  }, [mode, graphFn]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in-50">
      <div className="fixed inset-0" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-300 overflow-hidden z-10 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-200 bg-[#002f6c] text-white">
          <div className="flex items-center gap-3">
            <span className="font-bold text-sm">SAT Calculator</span>
            <div className="flex items-center bg-white/20 p-0.5 rounded text-xs font-semibold">
              <button
                onClick={() => setMode('calc')}
                className={`px-2.5 py-0.5 rounded transition-colors ${
                  mode === 'calc' ? 'bg-white text-[#002f6c]' : 'text-white hover:bg-white/10'
                }`}
              >
                Scientific
              </button>
              <button
                onClick={() => setMode('graph')}
                className={`px-2.5 py-0.5 rounded transition-colors ${
                  mode === 'graph' ? 'bg-white text-[#002f6c]' : 'text-white hover:bg-white/10'
                }`}
              >
                Graphing
              </button>
            </div>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-white/20 rounded cursor-pointer">
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {mode === 'calc' ? (
          <div className="p-5">
            {/* Screen */}
            <div className="bg-slate-100 border border-slate-300 rounded-lg p-3 text-right font-mono mb-4">
              <div className="text-sm text-slate-500 min-h-[22px] overflow-x-auto truncate">
                {expression || '0'}
              </div>
              <div className="text-2xl font-bold text-slate-900 min-h-[32px] overflow-x-auto">
                {result || ' '}
              </div>
            </div>

            {/* Keypad */}
            <div className="grid grid-cols-5 gap-2 text-sm font-semibold">
              {/* Row 1 */}
              <button onClick={() => append('sin(')} className="calc-btn">sin</button>
              <button onClick={() => append('cos(')} className="calc-btn">cos</button>
              <button onClick={() => append('tan(')} className="calc-btn">tan</button>
              <button onClick={clearAll} className="calc-btn text-red-600 bg-red-50 hover:bg-red-100">AC</button>
              <button onClick={backspace} className="calc-btn"><Delete className="w-4 h-4 mx-auto" /></button>

              {/* Row 2 */}
              <button onClick={() => append('sqrt(')} className="calc-btn">√</button>
              <button onClick={() => append('(')} className="calc-btn">(</button>
              <button onClick={() => append(')')} className="calc-btn">)</button>
              <button onClick={() => append('^')} className="calc-btn">xʸ</button>
              <button onClick={() => append('/')} className="calc-btn font-mono text-indigo-600">÷</button>

              {/* Row 3 */}
              <button onClick={() => append('log(')} className="calc-btn">log</button>
              <button onClick={() => append('7')} className="calc-num">7</button>
              <button onClick={() => append('8')} className="calc-num">8</button>
              <button onClick={() => append('9')} className="calc-num">9</button>
              <button onClick={() => append('*')} className="calc-btn font-mono text-indigo-600">×</button>

              {/* Row 4 */}
              <button onClick={() => append('ln(')} className="calc-btn">ln</button>
              <button onClick={() => append('4')} className="calc-num">4</button>
              <button onClick={() => append('5')} className="calc-num">5</button>
              <button onClick={() => append('6')} className="calc-num">6</button>
              <button onClick={() => append('-')} className="calc-btn font-mono text-indigo-600">−</button>

              {/* Row 5 */}
              <button onClick={() => append('π')} className="calc-btn">π</button>
              <button onClick={() => append('1')} className="calc-num">1</button>
              <button onClick={() => append('2')} className="calc-num">2</button>
              <button onClick={() => append('3')} className="calc-num">3</button>
              <button onClick={() => append('+')} className="calc-btn font-mono text-indigo-600">+</button>

              {/* Row 6 */}
              <button onClick={() => append('e')} className="calc-btn">e</button>
              <button onClick={() => append('0')} className="calc-num col-span-2">0</button>
              <button onClick={() => append('.')} className="calc-num">.</button>
              <button onClick={evaluate} className="calc-btn bg-blue-600 hover:bg-blue-700 text-white font-bold text-base">=</button>
            </div>
          </div>
        ) : (
          <div className="p-4 flex flex-col items-center">
            {/* Function input */}
            <div className="w-full flex items-center gap-2 mb-3">
              <span className="font-mono font-bold text-sm text-slate-700">y =</span>
              <input
                type="text"
                value={graphFn}
                onChange={(e) => setGraphFn(e.target.value)}
                placeholder="e.g. 2*x + 1 or x^2 - 4"
                className="flex-1 px-3 py-1.5 text-sm font-mono border border-slate-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-600"
              />
            </div>
            <div className="w-full border border-slate-300 rounded-lg overflow-hidden bg-white shadow-inner">
              <canvas
                ref={canvasRef}
                width={460}
                height={280}
                className="w-full h-auto bg-slate-50"
              />
            </div>
            <div className="text-[11px] text-slate-500 mt-2">
              Tip: Supports x^2, 2*x - 3, sin(x), sqrt(x), etc.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
