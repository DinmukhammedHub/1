import React from 'react';
import { X, Highlighter, Trash2, ExternalLink } from 'lucide-react';
import { HighlightItem } from '../types/sat';

interface HighlightsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  highlights: HighlightItem[];
  onRemoveHighlight: (id: string) => void;
  onJumpToQuestion: (questionId: number) => void;
}

export const HighlightsDrawer: React.FC<HighlightsDrawerProps> = ({
  isOpen,
  onClose,
  highlights,
  onRemoveHighlight,
  onJumpToQuestion,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/40 backdrop-blur-xs animate-in fade-in-50">
      <div className="fixed inset-0" onClick={onClose} />
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl border-l border-slate-300 z-10 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2">
            <Highlighter className="w-5 h-5 text-slate-800" />
            <h3 className="text-base font-bold text-slate-900">Highlights & Notes</h3>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-200 rounded-full cursor-pointer">
            <X className="w-5 h-5 text-slate-600" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {highlights.length === 0 ? (
            <div className="text-center py-16 text-slate-400">
              <Highlighter className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p className="text-sm font-medium">No highlights or notes recorded yet.</p>
              <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                Highlight any text in reading passages with your mouse to create annotations.
              </p>
            </div>
          ) : (
            highlights.map((item) => (
              <div
                key={item.id}
                className="p-3.5 border border-slate-200 rounded-lg bg-slate-50/70 hover:bg-slate-50 transition-colors space-y-2 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                    Question {item.questionId}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        onJumpToQuestion(item.questionId);
                        onClose();
                      }}
                      className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
                    >
                      <span>Jump</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => onRemoveHighlight(item.id)}
                      className="text-slate-400 hover:text-red-600 p-1 cursor-pointer"
                      title="Delete highlight"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div
                  className={`text-sm italic p-2 rounded border ${
                    item.color === 'yellow'
                      ? 'bg-yellow-100 border-yellow-200 text-yellow-950'
                      : item.color === 'pink'
                      ? 'bg-pink-100 border-pink-200 text-pink-950'
                      : item.color === 'blue'
                      ? 'bg-sky-100 border-sky-200 text-sky-950'
                      : 'bg-white border-blue-200 underline decoration-blue-500 text-slate-900'
                  }`}
                >
                  "{item.text}"
                </div>

                {item.note && (
                  <div className="text-xs text-slate-700 bg-white p-2 rounded border border-slate-200">
                    <strong>Note:</strong> {item.note}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
