import React, { useState, useRef } from 'react';
import { Highlighter, Trash2 } from 'lucide-react';
import { HighlightItem } from '../types/sat';
import { SatGraphic } from './SatGraphic';

interface StimulusPaneProps {
  passage?: string;
  passageTitle?: string;
  questionId: number;
  graphicType?: string;
  highlights: HighlightItem[];
  onAddHighlight: (highlight: Omit<HighlightItem, 'id' | 'timestamp'>) => void;
  onRemoveHighlight: (id: string) => void;
  isLineReaderActive: boolean;
  fontSize: 'normal' | 'large' | 'xlarge';
}

export const StimulusPane: React.FC<StimulusPaneProps> = ({
  passage,
  passageTitle,
  questionId,
  graphicType,
  highlights,
  onAddHighlight,
  onRemoveHighlight,
  isLineReaderActive,
  fontSize,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [selectedText, setSelectedText] = useState('');
  const [selectionRange, setSelectionRange] = useState<{ x: number; y: number } | null>(null);
  const [lineReaderY, setLineReaderY] = useState(120);

  const textSizeClass = {
    normal: 'text-[16px] leading-[1.65]',
    large: 'text-[18px] leading-[1.7]',
    xlarge: 'text-[20px] leading-[1.75]',
  }[fontSize];

  const handleMouseUp = () => {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || !selection.toString().trim()) {
      setSelectionRange(null);
      setSelectedText('');
      return;
    }

    const text = selection.toString().trim();
    if (text.length > 0) {
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      const containerRect = containerRef.current?.getBoundingClientRect();

      if (containerRect) {
        setSelectionRange({
          x: Math.max(10, rect.left - containerRect.left + rect.width / 2 - 80),
          y: Math.max(10, rect.top - containerRect.top - 46),
        });
        setSelectedText(text);
      }
    }
  };

  const applyHighlight = (color: 'yellow' | 'pink' | 'blue' | 'underline') => {
    if (!selectedText) return;
    onAddHighlight({
      questionId,
      text: selectedText,
      color,
    });
    setSelectionRange(null);
    setSelectedText('');
    window.getSelection()?.removeAllRanges();
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isLineReaderActive || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const relativeY = e.clientY - rect.top;
    setLineReaderY(Math.max(20, Math.min(rect.height - 40, relativeY)));
  };

  const currentQuestionHighlights = highlights.filter((h) => h.questionId === questionId);

  return (
    <div
      ref={containerRef}
      onMouseUp={handleMouseUp}
      onMouseMove={handleMouseMove}
      className="relative h-full flex flex-col overflow-y-auto pl-8 pr-12 pt-8 pb-8 bg-white select-text"
    >
      {/* Visual graphic/chart if present in stimulus */}
      {graphicType && (
        <div className="mb-4">
          <SatGraphic graphicType={graphicType} />
        </div>
      )}

      {/* Passage Prose matching Bluebook 1:1 margins & wrapping */}
      {passage ? (
        <div className="max-w-[660px]">
          <div
            className={`font-reading text-[#111827] ${textSizeClass} tracking-normal select-text whitespace-pre-line`}
            dangerouslySetInnerHTML={{ __html: passage }}
          />
        </div>
      ) : !graphicType ? (
        <div className="h-full flex items-center justify-center text-slate-400 text-sm italic font-reading">
          This question has no stimulus passage. Read the prompt directly on the right.
        </div>
      ) : null}

      {/* Floating Highlight Toolbar */}
      {selectionRange && (
        <div
          style={{ top: `${selectionRange.y}px`, left: `${selectionRange.x}px` }}
          className="absolute z-40 flex items-center gap-1.5 bg-black text-white px-2 py-1.5 rounded-lg shadow-2xl border border-slate-700 animate-in fade-in-50 zoom-in-95"
        >
          <button
            onClick={() => applyHighlight('yellow')}
            className="w-5 h-5 rounded-full bg-yellow-300 ring-1 ring-yellow-500 cursor-pointer"
            title="Highlight Yellow"
          />
          <button
            onClick={() => applyHighlight('pink')}
            className="w-5 h-5 rounded-full bg-pink-300 ring-1 ring-pink-500 cursor-pointer"
            title="Highlight Pink"
          />
          <button
            onClick={() => applyHighlight('blue')}
            className="w-5 h-5 rounded-full bg-sky-300 ring-1 ring-sky-500 cursor-pointer"
            title="Highlight Blue"
          />
          <button
            onClick={() => applyHighlight('underline')}
            className="px-1 text-xs font-bold underline underline-offset-2 hover:text-blue-300 cursor-pointer"
            title="Underline"
          >
            U
          </button>
        </div>
      )}

      {/* Highlight notes list if any */}
      {currentQuestionHighlights.length > 0 && (
        <div className="mt-8 pt-4 border-t border-slate-200 max-w-[660px]">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Highlighter className="w-3.5 h-3.5 text-slate-600" />
            <span>Notes & Highlights ({currentQuestionHighlights.length})</span>
          </div>
          <div className="space-y-1.5">
            {currentQuestionHighlights.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between text-xs p-2 rounded bg-slate-50 border border-slate-200"
              >
                <span className={`italic truncate max-w-[85%] ${
                  item.color === 'yellow' ? 'bg-yellow-200 px-1 rounded' :
                  item.color === 'pink' ? 'bg-pink-200 px-1 rounded' :
                  item.color === 'blue' ? 'bg-sky-200 px-1 rounded' :
                  'underline decoration-blue-500'
                }`}>
                  "{item.text}"
                </span>
                <button
                  onClick={() => onRemoveHighlight(item.id)}
                  className="text-slate-400 hover:text-red-600 p-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Line Reader Mask Tool */}
      {isLineReaderActive && (
        <div className="pointer-events-none absolute inset-0 z-20 overflow-hidden">
          <div
            style={{ height: `${Math.max(0, lineReaderY - 20)}px` }}
            className="w-full bg-slate-900/40 backdrop-blur-[0.5px]"
          />
          <div
            style={{ top: `${Math.max(0, lineReaderY - 20)}px`, height: '42px' }}
            className="w-full border-y-2 border-amber-400 bg-amber-50/15"
          />
          <div
            style={{ top: `${Math.max(42, lineReaderY + 22)}px` }}
            className="absolute inset-x-0 bottom-0 bg-slate-900/40 backdrop-blur-[0.5px]"
          />
        </div>
      )}
    </div>
  );
};
