import React, { useState } from 'react';
import { HelpCircle } from 'lucide-react';
import { Question, QuestionState } from '../types/sat';
import { SatGraphic } from './SatGraphic';

interface QuestionPaneProps {
  question: Question;
  questionNumber: number;
  questionState: QuestionState;
  onSelectOption: (optionId: 'A' | 'B' | 'C' | 'D') => void;
  onToggleCrossOption: (optionId: 'A' | 'B' | 'C' | 'D') => void;
  onToggleMarkForReview: () => void;
  onUpdateSPR: (val: string) => void;
  fontSize: 'normal' | 'large' | 'xlarge';
}

export const QuestionPane: React.FC<QuestionPaneProps> = ({
  question,
  questionNumber,
  questionState,
  onSelectOption,
  onToggleCrossOption,
  onToggleMarkForReview,
  onUpdateSPR,
  fontSize,
}) => {
  const [isEliminatorActive, setIsEliminatorActive] = useState(true);
  const [showSprHelp, setShowSprHelp] = useState(false);
  const [viewMode, setViewMode] = useState<'interactive' | 'image'>(
    question.image ? 'image' : 'interactive'
  );

  const getFontSize = () => {
    if (fontSize === 'large') return '18px';
    if (fontSize === 'xlarge') return '20px';
    return '16px';
  };

  return (
    <div className="h-full flex flex-col overflow-y-auto bg-white select-none">
      {/* 1. Хедер вопроса */}
      <div className="bg-[#f4f5f7] px-5 sm:px-7 py-2.5 flex items-center justify-between">
        {/* Слева: Черный квадрат с номером + Mark for Review */}
        <div className="flex items-center gap-3">
          {/* Черный квадрат слева с закругленными углами (border-radius: 4px), внутри белая цифра */}
          <div
            style={{
              borderRadius: '4px',
              fontFamily: 'system-ui, -apple-system, sans-serif',
            }}
            className="w-[32px] h-[32px] bg-black text-white font-bold flex items-center justify-center text-[15px] shrink-0 select-none shadow-xs"
          >
            {questionNumber}
          </div>

          {/* Иконка закладки (Outline Bookmark) и текст "Mark for Review" */}
          <button
            type="button"
            onClick={onToggleMarkForReview}
            style={{
              fontFamily: 'system-ui, -apple-system, sans-serif',
              fontWeight: 500,
              color: questionState.isMarkedForReview ? '#b91c1c' : '#1e1e1e',
            }}
            className="flex items-center gap-2 py-1 text-[14px] transition-colors cursor-pointer select-none hover:text-black"
            title="Mark for Review"
          >
            <svg
              className={`w-[17px] h-[17px] ${
                questionState.isMarkedForReview
                  ? 'fill-red-600 text-red-600'
                  : 'text-[#1e1e1e] fill-none stroke-current'
              }`}
              viewBox="0 0 24 24"
              strokeWidth="1.8"
            >
              <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
            </svg>
            <span className="leading-none">Mark for Review</span>
          </button>
        </div>

        {/* Справа вверху: Кнопка "ABC" (Annotation Tool) — скругленный прямоугольник темно-синего цвета (#1d3a8a) */}
        {!question.isSPR && (
          <button
            type="button"
            onClick={() => setIsEliminatorActive(!isEliminatorActive)}
            style={{
              backgroundColor: isEliminatorActive ? '#1d3a8a' : '#94a3b8',
              borderRadius: '6px',
              fontFamily: 'system-ui, -apple-system, sans-serif',
            }}
            className="px-3 py-1.5 text-white transition-all cursor-pointer flex items-center justify-center shadow-xs hover:opacity-95"
            title="Option Eliminator / Annotation Tool"
          >
            <div className="relative font-bold text-[13px] tracking-wider flex items-center px-0.5">
              <span>ABC</span>
              <span className="absolute inset-x-[-2px] top-1/2 -rotate-15 h-[1.6px] bg-white transform -translate-y-1/2 pointer-events-none" />
            </div>
          </button>
        )}
      </div>

      {/* Снизу под хедером — пунктирная разделительная линия (border-bottom: 2px dashed #333) во всю ширину */}
      <div
        style={{ borderBottom: '2px dashed #333333' }}
        className="w-full shrink-0"
      />

      {/* Основной блок вопроса */}
      <div className="px-5 sm:px-7 py-6 flex-1 flex flex-col">
        {/* Переключатель между скопированной оригинальной картинкой и интерактивным UI при наличии картинки */}
        {question.image && (
          <div className="flex items-center justify-between mb-5 pb-3 border-b border-slate-200">
            <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
              <span>Отображение:</span>
              <span className="font-semibold text-slate-800">
                {viewMode === 'image' ? 'Оригинальный скриншот (картинка)' : 'Интерактивный UI'}
              </span>
            </div>
            <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg border border-slate-200">
              <button
                type="button"
                onClick={() => setViewMode('image')}
                className={`px-3 py-1 text-xs rounded-md transition-all cursor-pointer ${
                  viewMode === 'image'
                    ? 'bg-white text-black shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-black font-medium'
                }`}
              >
                Оригинальная картинка
              </button>
              <button
                type="button"
                onClick={() => setViewMode('interactive')}
                className={`px-3 py-1 text-xs rounded-md transition-all cursor-pointer ${
                  viewMode === 'interactive'
                    ? 'bg-white text-black shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-black font-medium'
                }`}
              >
                Интерактивный UI
              </button>
            </div>
          </div>
        )}

        {/* График для математики при наличии */}
        {question.section === 'math' && question.graphicType && (
          <div className="mb-4">
            <SatGraphic graphicType={question.graphicType} />
          </div>
        )}

        {/* Если вопрос SPR (Math) */}
        {question.isSPR ? (
          <div className="my-6 max-w-lg space-y-4 font-sans">
            <div className="flex items-center justify-between">
              <span className="text-[13px] font-bold text-slate-800 tracking-tight">
                Student-Produced Response
              </span>
              <button
                type="button"
                onClick={() => setShowSprHelp(true)}
                className="text-[13px] text-blue-700 hover:text-blue-900 hover:underline flex items-center gap-1 cursor-pointer font-medium"
              >
                <HelpCircle className="w-4 h-4" />
                <span>How to enter your answer</span>
              </button>
            </div>

            <div className="p-5 border-2 border-slate-300 rounded-xl bg-slate-50/70 space-y-3">
              <label className="block text-[13px] text-slate-600 font-medium">
                Enter your answer in the box provided:
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="text"
                  value={questionState.sprValue || ''}
                  onChange={(e) => {
                    const val = e.target.value.replace(/[^0-9./-]/g, '').slice(0, 7);
                    onUpdateSPR(val);
                  }}
                  placeholder="Answer"
                  className="w-48 px-4 py-2.5 bg-white border-2 border-slate-900 rounded-lg font-mono text-xl font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 shadow-xs"
                  autoComplete="off"
                  spellCheck="false"
                />
                {questionState.sprValue && (
                  <button
                    type="button"
                    onClick={() => onUpdateSPR('')}
                    className="text-xs text-slate-500 hover:text-slate-800 underline cursor-pointer"
                  >
                    Clear
                  </button>
                )}
              </div>

              <p className="text-[12px] text-slate-500 leading-normal">
                Accepts integers, fractions (e.g.,{' '}
                <span className="font-mono font-semibold text-slate-700">7/4</span>), or decimals
                (e.g., <span className="font-mono font-semibold text-slate-700">1.75</span>). Negative
                values can be entered with a leading minus sign.
              </p>
            </div>

            {/* Modal: Guidelines for Entering Student-Produced Responses */}
            {showSprHelp && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
                <div className="fixed inset-0" onClick={() => setShowSprHelp(false)} />
                <div className="relative w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-300 overflow-hidden z-10 p-6 space-y-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                    <h3 className="text-base font-bold text-slate-900">
                      How to Enter Student-Produced Responses
                    </h3>
                    <button
                      type="button"
                      onClick={() => setShowSprHelp(false)}
                      className="p-1 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="text-[13.5px] text-slate-700 space-y-3 leading-relaxed">
                    <p>
                      • You may enter up to <strong>5 characters</strong> for a positive answer and
                      up to <strong>6 characters</strong> (including a negative sign) for a
                      negative answer.
                    </p>
                    <p>
                      • If your answer is a fraction that doesn't fit in the provided space, enter
                      the decimal equivalent.
                    </p>
                    <p>
                      • If your answer is a decimal that doesn't fit in the provided space, round it
                      to fill the entire space (for example,{' '}
                      <span className="font-mono font-semibold">2/3</span> can be entered as{' '}
                      <span className="font-mono font-semibold">.6666</span>,{' '}
                      <span className="font-mono font-semibold">.6667</span>, or{' '}
                      <span className="font-mono font-semibold">0.667</span>).
                    </p>
                    <p>• You can enter a negative sign only as the first character.</p>
                    <p>• Do not enter symbols such as percent signs, commas, or dollar signs.</p>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex justify-end">
                    <button
                      type="button"
                      onClick={() => setShowSprHelp(false)}
                      className="px-5 py-2 bg-[#2554d7] hover:bg-[#1d46b8] text-white text-xs font-bold rounded-full cursor-pointer"
                    >
                      Understood
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : question.image && viewMode === 'image' ? (
          /* Режим 1: Отображение оригинальной вставленной картинки */
          <div className="w-full flex flex-col items-center pb-8 animate-in fade-in-50 duration-200">
            {/* Сама скопированная картинка */}
            <div className="w-full rounded-xl overflow-hidden border border-slate-300 shadow-sm bg-white">
              <img
                src={question.image}
                alt={`Question ${questionNumber}`}
                className="w-full h-auto block select-none"
              />
            </div>

            {/* Интерактивная панель выбора ответа под картинкой для теста и баллов */}
            <div className="w-full mt-5 p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Выбрать ответ:
                </span>
                <span className="text-sm font-bold text-slate-900">
                  {questionState.selectedOption
                    ? `Вариант (${questionState.selectedOption})`
                    : 'Не выбран'}
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                {(['A', 'B', 'C', 'D'] as const).map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => onSelectOption(opt)}
                    className={`w-10 h-10 rounded-full font-serif text-[16px] font-semibold border transition-all cursor-pointer flex items-center justify-center ${
                      questionState.selectedOption === opt
                        ? 'bg-[#1a1a1a] text-white border-black shadow-sm ring-2 ring-blue-500/20'
                        : 'bg-white text-slate-800 border-slate-300 hover:border-black'
                    }`}
                    title={`Выбрать (${opt})`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          /* Режим 2: Полнофункциональный интерактивный UI по спецификациям */
          <>
            {/* 2. Текст вопроса: Serif-шрифт (Georgia / Times New Roman / STIX Two Text), font-size: 16px, line-height: 1.5, color: #111111 */}
            <div className="mb-6">
              <div
                style={{
                  fontFamily: "Georgia, 'Times New Roman', 'STIX Two Text', 'Source Serif 4', serif",
                  fontSize: getFontSize(),
                  lineHeight: '1.5',
                  color: '#111111',
                }}
                className="whitespace-pre-line font-normal"
                dangerouslySetInnerHTML={{ __html: question.questionText }}
              />
            </div>

            {/* 3. Карточки вариантов ответов (Option Cards) */}
            <div className="space-y-3.5 pb-8">
              {question.options?.map((option) => {
                const isSelected = questionState.selectedOption === option.id;
                const isCrossed = questionState.crossedOptions.includes(option.id);

                return (
                  <div key={option.id} className="flex items-center w-full">
                    {/* Прямоугольные блоки с закругленными углами (border-radius: 12px, border: 1px solid #767676).
                        При выборе карточки: фон меняется на светлый голубовато-серый (#eef2f6), рамка становится 2px solid #1a1a1a */}
                    <button
                      type="button"
                      onClick={() => onSelectOption(option.id)}
                      style={{
                        borderRadius: '12px',
                        border: isSelected
                          ? '2px solid #1a1a1a'
                          : isCrossed
                          ? '1px solid #cbd5e1'
                          : '1px solid #767676',
                        backgroundColor: isSelected
                          ? '#eef2f6'
                          : isCrossed
                          ? 'rgba(248, 250, 252, 0.7)'
                          : '#ffffff',
                        padding: '16px 20px',
                      }}
                      className={`flex-1 flex items-center min-h-[58px] text-left transition-colors cursor-pointer select-none ${
                        isCrossed ? 'opacity-40' : 'hover:border-[#1a1a1a]'
                      }`}
                    >
                      {/* Внутри карточки слева: Круг закругленный (border: 1px solid #333), внутри заглавная буква шрифтом Georgia/Serif (НЕ жирным!) */}
                      <div
                        style={{
                          width: '28px',
                          height: '28px',
                          borderRadius: '50%',
                          border: isCrossed ? '1px solid #cbd5e1' : '1px solid #333333',
                          fontFamily: "Georgia, 'Times New Roman', 'STIX Two Text', serif",
                          fontWeight: 'normal',
                          fontSize: '15px',
                          color: isCrossed ? '#94a3b8' : '#111111',
                        }}
                        className="shrink-0 flex items-center justify-center bg-transparent"
                      >
                        {option.id}
                      </div>

                      {/* Текст ответа: Serif-шрифт, отступ слева от круга буквы — 20px */}
                      <span
                        style={{
                          marginLeft: '20px',
                          fontFamily:
                            "Georgia, 'Times New Roman', 'STIX Two Text', 'Source Serif 4', serif",
                          fontSize: getFontSize(),
                          lineHeight: '1.5',
                          color: '#111111',
                        }}
                        className={`flex-1 font-normal ${
                          isCrossed ? 'line-through text-slate-400' : ''
                        }`}
                        dangerouslySetInnerHTML={{ __html: option.text }}
                      />
                    </button>

                    {/* 4. Правая кнопка вычеркивания (Eliminate Choice):
                        - Находится за пределами правой границы карточки ответа.
                        - Круг с тонкой обводкой (border: 1px solid #333).
                        - Внутри кружка заглавная Serif-буква (A, B, C, D) тонкого начертания, перечеркнутая ровной горизонтальной линией по центру. */}
                    {isEliminatorActive && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleCrossOption(option.id);
                        }}
                        style={{
                          marginLeft: '16px',
                          width: '28px',
                          height: '28px',
                          borderRadius: '50%',
                          border: '1px solid #333333',
                          fontFamily: "Georgia, 'Times New Roman', 'STIX Two Text', serif",
                          fontWeight: 'normal',
                          fontSize: '14px',
                          color: isCrossed ? '#ffffff' : '#333333',
                          backgroundColor: isCrossed ? '#333333' : 'transparent',
                        }}
                        className="shrink-0 flex items-center justify-center relative hover:bg-slate-100 transition-colors cursor-pointer select-none"
                        title={
                          isCrossed
                            ? `Restore choice (${option.id})`
                            : `Eliminate choice (${option.id})`
                        }
                      >
                        {/* Заглавная буква Serif тонкого начертания */}
                        <span className="leading-none">{option.id}</span>

                        {/* Ровная горизонтальная линия по центру */}
                        <span
                          style={{
                            position: 'absolute',
                            left: '-2px',
                            right: '-2px',
                            top: '50%',
                            height: '1.5px',
                            backgroundColor: isCrossed ? '#ffffff' : '#333333',
                            transform: 'translateY(-50%)',
                            pointerEvents: 'none',
                          }}
                        />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
