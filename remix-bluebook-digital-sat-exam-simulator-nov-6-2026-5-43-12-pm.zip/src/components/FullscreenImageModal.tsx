import React, { useEffect } from 'react';

export interface ExamScreenshot {
  id: string;
  title: string;
  section: string;
  questionNumber: number;
  imageSrc: string;
}

export const EXAM_SCREENSHOTS: ExamScreenshot[] = [
  {
    id: 'rw1-q1',
    title: '1. Reading & Writing Mod 1 (Q1 Maple Trees)',
    section: 'Section 1, Module 1',
    questionNumber: 1,
    imageSrc: '/assets/aistudio/2_520471de.png',
  },
  {
    id: 'rw1-q24',
    title: '2. Reading & Writing Mod 1 (Q24 Local Bubble)',
    section: 'Section 1, Module 1',
    questionNumber: 24,
    imageSrc: '/assets/aistudio/3_a70f5d49.png',
  },
  {
    id: 'rw1-review',
    title: '3. Reading & Writing Mod 1 (Check Your Work)',
    section: 'Section 1, Module 1',
    questionNumber: 27,
    imageSrc: '/assets/aistudio/4_6b707463.png',
  },
  {
    id: 'rw2-q3',
    title: '4. Reading & Writing Mod 2 (Q3 Alma W. Thomas)',
    section: 'Section 1, Module 2',
    questionNumber: 3,
    imageSrc: '/assets/aistudio/2_b7c165e8.png',
  },
  {
    id: 'rw2-q16',
    title: '5. Reading & Writing Mod 2 (Q16 Louisa May Alcott)',
    section: 'Section 1, Module 2',
    questionNumber: 16,
    imageSrc: '/assets/aistudio/5_faa002ac.png',
  },
  {
    id: 'rw2-q25',
    title: '6. Reading & Writing Mod 2 (Q25 Robert Fulton)',
    section: 'Section 1, Module 2',
    questionNumber: 25,
    imageSrc: '/assets/aistudio/6_cac23694.png',
  },
  {
    id: 'rw2-review',
    title: '7. Reading & Writing Mod 2 (Check Your Work)',
    section: 'Section 1, Module 2',
    questionNumber: 27,
    imageSrc: '/assets/aistudio/7_0c4aaaf0.png',
  },
  {
    id: 'math1-q1',
    title: '8. Math Mod 1 (Q1 Lorenzo Cereal)',
    section: 'Section 2, Module 1',
    questionNumber: 1,
    imageSrc: '/assets/aistudio/2_0139b95e.png',
  },
  {
    id: 'math1-q16',
    title: '9. Math Mod 1 (Q16 System 39x)',
    section: 'Section 2, Module 1',
    questionNumber: 16,
    imageSrc: '/assets/aistudio/3_88df1f9c.png',
  },
  {
    id: 'math1-q21',
    title: '10. Math Mod 1 (Q21 x-intercept)',
    section: 'Section 2, Module 1',
    questionNumber: 21,
    imageSrc: '/assets/aistudio/4_a6c387ec.png',
  },
  {
    id: 'math1-review',
    title: '11. Math Mod 1 (Check Your Work)',
    section: 'Section 2, Module 1',
    questionNumber: 22,
    imageSrc: '/assets/aistudio/8_209d4484.png',
  },
  {
    id: 'math2-q1',
    title: '12. Math Mod 2 (Q1 Charity 165 people)',
    section: 'Section 2, Module 2',
    questionNumber: 1,
    imageSrc: '/assets/aistudio/5_ce3a61f6.png',
  },
  {
    id: 'math2-q1-alt',
    title: '13. Math Mod 2 (Q1 Charity Event Alt)',
    section: 'Section 2, Module 2',
    questionNumber: 1,
    imageSrc: '/assets/aistudio/image_1d99c68f.png',
  },
  {
    id: 'math2-q21',
    title: '14. Math Mod 2 (Q21 Function f(5) - f(a))',
    section: 'Section 2, Module 2',
    questionNumber: 21,
    imageSrc: '/assets/aistudio/7_ecb1e350.png',
  },
  {
    id: 'math2-review',
    title: '15. Math Mod 2 (Check Your Work)',
    section: 'Section 2, Module 2',
    questionNumber: 22,
    imageSrc: '/assets/aistudio/9_a3e4dc12.png',
  },
];

interface FullscreenImageModalProps {
  isOpen: boolean;
  onClose: () => void;
  activePhotoIndex: number;
  onSelectPhotoIndex: (index: number) => void;
}

export const FullscreenImageModal: React.FC<FullscreenImageModalProps> = ({
  isOpen,
  onClose,
  activePhotoIndex,
  onSelectPhotoIndex,
}) => {
  const currentPhoto = EXAM_SCREENSHOTS[activePhotoIndex] || EXAM_SCREENSHOTS[0];

  useEffect(() => {
    if (!isOpen) return;

    // Попытка развернуть на весь экран браузера
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleClose();
      } else if (e.key === 'ArrowRight') {
        onSelectPhotoIndex((activePhotoIndex + 1) % EXAM_SCREENSHOTS.length);
      } else if (e.key === 'ArrowLeft') {
        onSelectPhotoIndex(
          (activePhotoIndex - 1 + EXAM_SCREENSHOTS.length) % EXAM_SCREENSHOTS.length
        );
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, activePhotoIndex]);

  const handleClose = () => {
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    }
    onClose();
  };

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSelectPhotoIndex(
      (activePhotoIndex - 1 + EXAM_SCREENSHOTS.length) % EXAM_SCREENSHOTS.length
    );
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSelectPhotoIndex((activePhotoIndex + 1) % EXAM_SCREENSHOTS.length);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#1e1e1e] select-none overflow-hidden m-0 p-0 border-0">
      {/* Аутентичная панель заголовка Windows Bluebook (из image_9de0c57e.png) — компактный размер */}
      <div className="w-full h-[22px] bg-[#202020] flex items-center justify-between select-none shrink-0 m-0 p-0 border-0 z-20">
        {/* Слева: Оригинальный заголовок и логотип Bluebook */}
        <div className="flex items-center h-full select-none shrink-0 overflow-hidden">
          <img
            src="/assets/aistudio/image_9de0c57e.png"
            alt="Bluebook"
            className="h-[21px] w-auto select-none pointer-events-none block object-contain"
          />
        </div>

        {/* Справа: Кнопки управления окном Windows:
            - На '-' (свернуть): переход на предыдущее фото
            - На 'квадрат' (развернуть): переход на следующее фото
            - На 'крест' (закрыть): выход просто на сайт
        */}
        <div className="flex items-center h-full shrink-0">
          {/* Кнопка "—" (Минус) — ПРЕДЫДУЩЕЕ ФОТО */}
          <button
            type="button"
            onClick={handlePrev}
            className="w-[34px] h-full flex items-center justify-center hover:bg-[#333333] active:bg-[#444444] transition-colors cursor-pointer group"
          >
            <div className="w-[8px] h-[1px] bg-white group-hover:bg-white" />
          </button>

          {/* Кнопка "□" (Квадрат) — СЛЕДУЮЩЕЕ ФОТО */}
          <button
            type="button"
            onClick={handleNext}
            className="w-[34px] h-full flex items-center justify-center hover:bg-[#333333] active:bg-[#444444] transition-colors cursor-pointer group"
          >
            <div className="w-[8px] h-[8px] border border-white" />
          </button>

          {/* Кнопка "✕" (Крест) — ВЫХОД НА САЙТ */}
          <button
            type="button"
            onClick={handleClose}
            className="w-[34px] h-full flex items-center justify-center hover:bg-[#e81123] active:bg-[#c4101e] transition-colors cursor-pointer group"
          >
            <svg
              className="w-[8px] h-[8px] text-white stroke-current"
              viewBox="0 0 10 10"
            >
              <line x1="0.5" y1="0.5" x2="9.5" y2="9.5" strokeWidth="1.2" />
              <line x1="9.5" y1="0.5" x2="0.5" y2="9.5" strokeWidth="1.2" />
            </svg>
          </button>
        </div>
      </div>

      {/* Полноэкранное изображение теста БЕЗ БОКОВЫХ ГРАНИЦ И ПОЛЕЙ */}
      <div className="flex-1 w-full h-[calc(100vh-22px)] m-0 p-0 overflow-hidden relative bg-[#e8eef7]">
        <img
          key={currentPhoto.id}
          src={currentPhoto.imageSrc}
          alt={currentPhoto.title}
          className="w-full h-full object-fill select-none block m-0 p-0 border-0"
        />
      </div>
    </div>
  );
};
