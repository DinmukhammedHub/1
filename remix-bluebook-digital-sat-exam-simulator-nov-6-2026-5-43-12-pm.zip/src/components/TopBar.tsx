import React, { useState } from 'react';
import { 
  Calculator, 
  BookOpen, 
  Maximize2, 
  Minimize2, 
  Eye, 
  Play, 
  Pause,
  RotateCcw,
  Clock,
  Sliders
} from 'lucide-react';
import { SectionType } from '../types/sat';
import { TimerControlModal } from './TimerControlModal';
import { EXAM_SCREENSHOTS } from './FullscreenImageModal';

interface TopBarProps {
  sectionTitle: string;
  moduleNumber: number;
  sectionType: SectionType;
  timeRemainingSeconds: number;
  isTimerRunning: boolean;
  onToggleTimerRunning: () => void;
  isTimerHidden: boolean;
  onToggleTimerHidden: () => void;
  onResetTimer: () => void;
  onOpenDirections: () => void;
  onOpenHighlights: () => void;
  onOpenCalculator: () => void;
  onOpenReference: () => void;
  onToggleLineReader: () => void;
  isLineReaderActive: boolean;
  fontSize: 'normal' | 'large' | 'xlarge';
  onChangeFontSize: (size: 'normal' | 'large' | 'xlarge') => void;
  onSwitchSection: (section: SectionType, module: 1 | 2) => void;
  onSetTimeRemainingSeconds: (seconds: number) => void;
  defaultModuleSeconds?: number;
  onOpenBreakScreen?: () => void;
  onOpenSectionIntro?: () => void;
  onOpenFullscreenMock?: (photoIndex?: number) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  sectionTitle,
  moduleNumber,
  sectionType,
  timeRemainingSeconds,
  isTimerRunning,
  onToggleTimerRunning,
  isTimerHidden,
  onToggleTimerHidden,
  onResetTimer,
  onOpenDirections,
  onOpenHighlights,
  onOpenCalculator,
  onOpenReference,
  onToggleLineReader,
  isLineReaderActive,
  fontSize,
  onChangeFontSize,
  onSwitchSection,
  onSetTimeRemainingSeconds,
  defaultModuleSeconds = 1920,
  onOpenBreakScreen,
  onOpenSectionIntro,
  onOpenFullscreenMock,
}) => {
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isTimerControlOpen, setIsTimerControlOpen] = useState(false);

  const minutes = Math.floor(timeRemainingSeconds / 60);
  const seconds = timeRemainingSeconds % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  return (
    <header className="w-full bg-[#e8eef7] select-none z-30">
      {/* Main Top Header - Exactly matching user color swatch */}
      <div className="relative bg-[#e8eef7] px-8 pt-3 pb-2.5 flex items-center justify-between min-h-[76px]">
        {/* Left: Section 1, Module 2: Reading and Writing & Directions v */}
        <div className="flex flex-col items-start min-w-[320px]">
          <h1 className="text-[19px] font-semibold text-[#111827] tracking-tight leading-tight font-sans">
            {sectionTitle}
          </h1>
          <button
            onClick={onOpenDirections}
            className="flex items-center gap-1.5 text-[14px] text-[#111827] hover:underline font-normal mt-1 cursor-pointer transition-colors"
            title="Directions"
          >
            <span>Directions</span>
            <svg className="w-3.5 h-3.5 stroke-[2.2] text-[#111827]" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path d="M6 9l6 6 6-6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>

        {/* Center: Official Bluebook Running Timer & Hide Button 1:1 */}
        <div className="absolute left-1/2 -translate-x-1/2 flex flex-col items-center justify-center">
          {/* Time digits */}
          <div className="text-[26px] font-semibold text-[#111827] tracking-tight leading-none font-sans">
            {isTimerHidden ? (
              <span className="text-slate-500 text-sm font-medium tracking-normal">
                Timer Hidden
              </span>
            ) : (
              <span>{formattedTime}</span>
            )}
          </div>

          {/* Hide / Show Pill Button with authentic 1px black outline */}
          <div className="mt-1">
            <button
              onClick={onToggleTimerHidden}
              className="px-4 py-[1px] text-[12px] font-semibold text-[#111827] border border-black rounded-full bg-transparent hover:bg-black/5 active:scale-95 transition-all cursor-pointer leading-tight"
            >
              {isTimerHidden ? 'Show' : 'Hide'}
            </button>
          </div>
        </div>

        {/* Right: 100% Battery, Highlights & Notes / Calculator, More */}
        <div className="flex flex-col items-end min-w-[280px]">
          {/* Battery Status: 100% */}
          <div className="flex items-center gap-1.5 text-[12px] font-medium text-[#111827] mb-1.5 mr-0.5">
            <span className="font-sans font-medium text-[12px] text-[#111827]">
              100%
            </span>
            {/* Battery Icon with full charge */}
            <div className="w-[22px] h-[11px] border border-black rounded-[2.5px] p-[1px] flex items-center relative">
              <div className="h-full bg-black rounded-[1px] w-full" />
              <div className="w-[1.5px] h-[4px] bg-black absolute -right-[2.5px] top-[2.5px] rounded-r-[1px]" />
            </div>
          </div>

          {/* Action Buttons Row */}
          <div className="flex items-center gap-5 mr-0.5">
            {sectionType === 'math' ? (
              /* Math Section Actions: Calculator and Reference (x²) matching Image 2 */
              <>
                {/* Calculator Button */}
                <button
                  onClick={onOpenCalculator}
                  className="flex flex-col items-center justify-center text-[#002f6c] hover:opacity-75 transition-opacity cursor-pointer group"
                  title="Desmos Graphing Calculator"
                >
                  <div className="flex items-center justify-center h-[18px]">
                    <svg
                      className="w-[17px] h-[17px] text-[#111827]"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.9"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <rect x="4" y="2" width="16" height="20" rx="2" />
                      <line x1="8" y1="6" x2="16" y2="6" strokeWidth="2.2" />
                      <line x1="16" y1="14" x2="16" y2="18" strokeWidth="2" />
                      <line x1="16" y1="10" x2="16" y2="10" strokeWidth="2.2" />
                      <line x1="12" y1="10" x2="12" y2="10" strokeWidth="2.2" />
                      <line x1="8" y1="10" x2="8" y2="10" strokeWidth="2.2" />
                      <line x1="12" y1="14" x2="12" y2="14" strokeWidth="2.2" />
                      <line x1="8" y1="14" x2="8" y2="14" strokeWidth="2.2" />
                      <line x1="12" y1="18" x2="12" y2="18" strokeWidth="2.2" />
                      <line x1="8" y1="18" x2="8" y2="18" strokeWidth="2.2" />
                    </svg>
                  </div>
                  <span className="text-[12.5px] font-medium text-[#002f6c] mt-0.5 tracking-tight font-sans">
                    Calculator
                  </span>
                </button>

                {/* Reference Sheet Button with Bold Serif x² Icon matching Image 2 */}
                <button
                  onClick={onOpenReference}
                  className="flex flex-col items-center justify-center text-[#002f6c] hover:opacity-75 transition-opacity cursor-pointer group"
                  title="Math Reference Sheet"
                >
                  <div className="flex items-center justify-center h-[18px]">
                    <span className="font-serif font-black italic text-[17px] text-[#111827] leading-none select-none tracking-tighter">
                      x<sup className="text-[10px] font-bold not-italic ml-0.5 -top-1 relative">2</sup>
                    </span>
                  </div>
                  <span className="text-[12.5px] font-medium text-[#002f6c] mt-0.5 tracking-tight font-sans">
                    Reference
                  </span>
                </button>
              </>
            ) : (
              /* Reading & Writing Action: Highlights & Notes */
              <button
                onClick={onOpenHighlights}
                className="flex flex-col items-center justify-center text-[#002f6c] hover:opacity-75 transition-opacity cursor-pointer group"
                title="Highlights & Notes"
              >
                <div className="flex items-center gap-[2px] h-[18px]">
                  {/* Marker with angled tip & underline */}
                  <svg
                    className="w-[17px] h-[17px] text-[#111827]"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.1"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M14 4l3 3L8 16l-3.5 1 1-3.5L14 4z" />
                    <path d="M6 13.5l3 3" />
                    <path d="M3 21h7" />
                  </svg>
                  {/* Dog-eared Note with horizontal lines */}
                  <svg
                    className="w-[16px] h-[16px] text-[#111827]"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.1"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                    <polyline points="14 2 14 8 20 8" />
                    <line x1="8" y1="13" x2="16" y2="13" />
                    <line x1="8" y1="17" x2="13" y2="17" />
                  </svg>
                </div>
                <span className="text-[12.5px] font-medium text-[#002f6c] mt-0.5 tracking-tight font-sans">
                  Highlights & Notes
                </span>
              </button>
            )}

            {/* More Menu Button */}
            <div className="relative">
              <button
                onClick={() => setIsMoreMenuOpen(!isMoreMenuOpen)}
                className="flex flex-col items-center justify-center text-[#002f6c] hover:opacity-75 transition-opacity cursor-pointer group"
                title="More"
              >
                <div className="flex items-center justify-center h-[18px]">
                  {/* 3 vertical dots icon matching Image 1 & 2 */}
                  <svg className="w-[18px] h-[18px] text-[#111827]" viewBox="0 0 24 24" fill="currentColor">
                    <circle cx="12" cy="4" r="2.2" />
                    <circle cx="12" cy="12" r="2.2" />
                    <circle cx="12" cy="20" r="2.2" />
                  </svg>
                </div>
                <span className="text-[12.5px] font-medium text-[#002f6c] mt-0.5 tracking-tight font-sans">
                  More
                </span>
              </button>

              {/* More Dropdown Menu */}
              {isMoreMenuOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setIsMoreMenuOpen(false)}
                  />
                  <div className="absolute right-0 top-full mt-2 w-80 max-h-[85vh] overflow-y-auto bg-white border border-slate-300 shadow-2xl rounded-lg p-2.5 z-50 text-slate-800">
                    {/* Список всех фото экзамена по порядку */}
                    <div className="px-2 py-1 text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center justify-between border-b border-slate-100 pb-1.5 mb-1.5">
                      <span>Фото экзамена Bluebook</span>
                      <span className="text-[10px] bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded font-bold">
                        {EXAM_SCREENSHOTS.length} фото
                      </span>
                    </div>

                    {onOpenFullscreenMock && (
                      <div className="space-y-1 mb-2.5">
                        {EXAM_SCREENSHOTS.map((photo, idx) => (
                          <button
                            key={photo.id}
                            type="button"
                            onClick={() => {
                              onOpenFullscreenMock(idx);
                              setIsMoreMenuOpen(false);
                            }}
                            className="w-full flex items-center justify-between px-2.5 py-1.5 text-xs hover:bg-blue-50/80 rounded-md text-left cursor-pointer border border-transparent hover:border-blue-200 transition-colors group"
                          >
                            <div className="flex items-center gap-2">
                              <span className="w-5 h-5 rounded-full bg-slate-100 group-hover:bg-blue-600 group-hover:text-white flex items-center justify-center font-bold text-[10px] text-slate-700 transition-colors shrink-0">
                                {idx + 1}
                              </span>
                              <div className="flex flex-col">
                                <span className="font-semibold text-slate-900 group-hover:text-blue-950 leading-tight">
                                  {photo.section} (Q{photo.questionNumber})
                                </span>
                                <span className="text-[10.5px] text-slate-500 leading-tight">
                                  {photo.title.split('(')[1]?.replace(')', '') || photo.title}
                                </span>
                              </div>
                            </div>
                            <Maximize2 className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600 shrink-0" />
                          </button>
                        ))}
                      </div>
                    )}

                    <div className="my-2 border-t border-slate-200" />

                    <div className="px-2 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      Official Bluebook Tools
                    </div>

                    <button
                      onClick={() => {
                        onOpenCalculator();
                        setIsMoreMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-2.5 py-2 text-sm hover:bg-slate-100 rounded-md font-medium text-left cursor-pointer"
                    >
                      <Calculator className="w-4 h-4 text-blue-700" />
                      <span>Desmos Graphing Calculator</span>
                    </button>

                    <button
                      onClick={() => {
                        onOpenReference();
                        setIsMoreMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-2.5 py-2 text-sm hover:bg-slate-100 rounded-md font-medium text-left cursor-pointer"
                    >
                      <BookOpen className="w-4 h-4 text-amber-600" />
                      <span>Math Reference Sheet</span>
                    </button>

                    <button
                      onClick={() => {
                        onToggleLineReader();
                        setIsMoreMenuOpen(false);
                      }}
                      className="w-full flex items-center justify-between px-2.5 py-2 text-sm hover:bg-slate-100 rounded-md font-medium text-left cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5">
                        <Eye className="w-4 h-4 text-emerald-600" />
                        <span>Line Reader</span>
                      </div>
                      <span className={`text-[11px] px-1.5 py-0.5 rounded font-mono ${isLineReaderActive ? 'bg-emerald-100 text-emerald-800 font-bold' : 'text-slate-400'}`}>
                        {isLineReaderActive ? 'ON' : 'OFF'}
                      </span>
                    </button>

                    <div className="my-2 border-t border-slate-200" />

                    {/* Timer Controls */}
                    <div className="px-2.5 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                      <span>Timer Controls</span>
                      <button
                        onClick={() => {
                          setIsTimerControlOpen(true);
                          setIsMoreMenuOpen(false);
                        }}
                        className="text-[11px] text-blue-700 hover:underline font-bold"
                      >
                        Settings
                      </button>
                    </div>
                    <div className="flex items-center gap-2 px-2 py-1">
                      <button
                        onClick={onToggleTimerRunning}
                        className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold rounded border transition-colors cursor-pointer ${
                          isTimerRunning
                            ? 'bg-amber-50 text-amber-800 border-amber-300 hover:bg-amber-100'
                            : 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                        }`}
                      >
                        {isTimerRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                        <span>{isTimerRunning ? 'Pause Timer' : 'Resume Timer'}</span>
                      </button>
                      <button
                        onClick={() => {
                          setIsTimerControlOpen(true);
                          setIsMoreMenuOpen(false);
                        }}
                        className="p-1.5 text-slate-700 hover:bg-slate-100 rounded border border-slate-200 cursor-pointer"
                        title="Set Custom Time"
                      >
                        <Sliders className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="my-2 border-t border-slate-200" />

                    {/* Quick Section/Module Switcher */}
                    <div className="px-2.5 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      Switch Test Module
                    </div>
                    <div className="space-y-1 px-1">
                      <button
                        onClick={() => {
                          onSwitchSection('rw', 1);
                          setIsMoreMenuOpen(false);
                        }}
                        className={`w-full text-left text-xs px-2 py-1.5 rounded transition-colors ${
                          sectionType === 'rw' && moduleNumber === 1
                            ? 'bg-blue-50 text-blue-900 font-bold'
                            : 'text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        Reading and Writing: Module 1 (Baseline)
                      </button>
                      <button
                        onClick={() => {
                          onSwitchSection('rw', 2);
                          setIsMoreMenuOpen(false);
                        }}
                        className={`w-full text-left text-xs px-2 py-1.5 rounded transition-colors ${
                          sectionType === 'rw' && moduleNumber === 2
                            ? 'bg-blue-50 text-blue-900 font-bold'
                            : 'text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        Reading and Writing: Module 2 (Hard)
                      </button>
                      <button
                        onClick={() => {
                          onSwitchSection('math', 1);
                          setIsMoreMenuOpen(false);
                        }}
                        className={`w-full text-left text-xs px-2 py-1.5 rounded transition-colors ${
                          sectionType === 'math' && moduleNumber === 1
                            ? 'bg-blue-50 text-blue-900 font-bold'
                            : 'text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        Math: Module 1 (Baseline)
                      </button>
                      <button
                        onClick={() => {
                          onSwitchSection('math', 2);
                          setIsMoreMenuOpen(false);
                        }}
                        className={`w-full text-left text-xs px-2 py-1.5 rounded transition-colors ${
                          sectionType === 'math' && moduleNumber === 2
                            ? 'bg-blue-50 text-blue-900 font-bold'
                            : 'text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        Math: Module 2 (Hard)
                      </button>

                      {/* Section Break & Directions Actions */}
                      <div className="pt-1.5 border-t border-slate-100 mt-1.5 space-y-1">
                        {onOpenBreakScreen && (
                          <button
                            onClick={() => {
                              onOpenBreakScreen();
                              setIsMoreMenuOpen(false);
                            }}
                            className="w-full text-left text-xs px-2 py-1.5 rounded transition-colors text-amber-950 bg-amber-50 hover:bg-amber-100 font-semibold flex items-center justify-between"
                          >
                            <span>10-Minute Break (Between Sections)</span>
                            <span className="text-[10px] bg-amber-200/80 text-amber-900 px-1.5 py-0.5 rounded font-bold">Break</span>
                          </button>
                        )}

                        {onOpenSectionIntro && (
                          <button
                            onClick={() => {
                              onOpenSectionIntro();
                              setIsMoreMenuOpen(false);
                            }}
                            className="w-full text-left text-xs px-2 py-1.5 rounded transition-colors text-blue-950 bg-blue-50 hover:bg-blue-100 font-semibold flex items-center justify-between"
                          >
                            <span>Section 2: Math Directions Screen</span>
                            <span className="text-[10px] bg-blue-200/80 text-blue-900 px-1.5 py-0.5 rounded font-bold">Intro</span>
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="my-2 border-t border-slate-200" />

                    {/* Text Size */}
                    <div className="px-2.5 py-1 text-[11px] font-semibold text-slate-500">
                      Text Size
                    </div>
                    <div className="flex items-center gap-1 px-2 pb-1.5">
                      {(['normal', 'large', 'xlarge'] as const).map((size) => (
                        <button
                          key={size}
                          onClick={() => onChangeFontSize(size)}
                          className={`flex-1 py-1 text-xs font-medium rounded border transition-colors ${
                            fontSize === size 
                              ? 'bg-slate-900 text-white border-slate-900' 
                              : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                          }`}
                        >
                          {size === 'normal' ? '100%' : size === 'large' ? '125%' : '150%'}
                        </button>
                      ))}
                    </div>

                    <div className="my-2 border-t border-slate-200" />

                    <button
                      onClick={() => {
                        toggleFullscreen();
                        setIsMoreMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-2.5 py-2 text-xs text-slate-700 hover:bg-slate-100 rounded-md font-medium text-left cursor-pointer"
                    >
                      {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                      <span>{isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* The Continuous Black Dashed Line - NO blue part after it */}
      <div className="bluebook-dashed-line" />

      {/* Timer Controls Modal */}
      <TimerControlModal
        isOpen={isTimerControlOpen}
        onClose={() => setIsTimerControlOpen(false)}
        timeRemainingSeconds={timeRemainingSeconds}
        isTimerRunning={isTimerRunning}
        onToggleTimerRunning={onToggleTimerRunning}
        onSetTimeRemainingSeconds={onSetTimeRemainingSeconds}
        isTimerHidden={isTimerHidden}
        onToggleTimerHidden={onToggleTimerHidden}
        defaultModuleSeconds={defaultModuleSeconds}
      />
    </header>
  );
};
