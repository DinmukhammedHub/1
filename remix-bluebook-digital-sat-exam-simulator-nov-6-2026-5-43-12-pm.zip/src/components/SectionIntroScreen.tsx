import React from 'react';
import { Clock, Calculator, BookOpen, CheckCircle, ArrowRight } from 'lucide-react';
import { SectionType } from '../types/sat';

interface SectionIntroScreenProps {
  sectionType: SectionType;
  moduleNumber: 1 | 2;
  studentName: string;
  onBegin: () => void;
}

export const SectionIntroScreen: React.FC<SectionIntroScreenProps> = ({
  sectionType,
  moduleNumber,
  studentName,
  onBegin,
}) => {
  const isMath = sectionType === 'math';

  return (
    <div className="h-screen w-screen bg-[#f0f2f5] flex flex-col justify-between select-none overflow-y-auto font-sans">
      {/* Main Content Area */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 sm:p-10 max-w-4xl mx-auto w-full">
        {/* Card */}
        <div className="w-full bg-white rounded-2xl shadow-md border border-slate-200/90 p-8 sm:p-10">
          {/* Header Badge & Title */}
          <div className="flex flex-col items-center text-center pb-6 border-b border-slate-100">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-3 py-1 rounded-full mb-3">
              {isMath ? 'Section 2' : 'Section 1'} • Module {moduleNumber} {moduleNumber === 2 ? '(Hard)' : '(Baseline)'}
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold text-[#111827] tracking-tight">
              {isMath ? 'Section 2: Math' : 'Section 1: Reading and Writing'}
            </h1>
            <p className="text-slate-500 text-sm mt-2">
              Module {moduleNumber} Directions & Testing Rules
            </p>
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-6">
            <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
              <Clock className="w-6 h-6 text-blue-700 shrink-0" />
              <div>
                <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
                  Timing
                </div>
                <div className="text-lg font-bold text-slate-900">
                  {isMath ? '35 minutes' : '32 minutes'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
              <CheckCircle className="w-6 h-6 text-emerald-600 shrink-0" />
              <div>
                <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
                  Questions
                </div>
                <div className="text-lg font-bold text-slate-900">
                  {isMath ? '22 questions' : '27 questions'}
                </div>
              </div>
            </div>
          </div>

          {/* Directions Text */}
          <div className="space-y-3 text-[14.5px] text-slate-700 leading-relaxed font-sans">
            {isMath ? (
              <>
                <p>
                  The questions in this section address a number of important math skills.
                </p>
                <p>
                  <strong>Use of a calculator is permitted for all questions.</strong> A built-in Desmos graphing calculator and a reference sheet of formulas are available at the top of your screen throughout this section.
                </p>
                <p>
                  Unless a question indicates otherwise, you may assume that the domain of any function is the set of all real numbers for which the function is defined.
                </p>
                <div className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-lg text-xs text-blue-950 space-y-1 mt-2">
                  <div className="font-bold uppercase tracking-wider text-blue-900">
                    Question Types:
                  </div>
                  <div>
                    • <strong>Multiple-choice:</strong> Select one best answer from the four options provided.
                  </div>
                  <div>
                    • <strong>Student-produced responses:</strong> Enter your numerical answer directly in the box provided (fractions, decimals, or integers).
                  </div>
                </div>
              </>
            ) : (
              <>
                <p>
                  The questions in this section address a number of important reading and writing skills. Each question includes one or more passages, which may also include a table or graph.
                </p>
                <p>
                  Read each passage and question carefully, and then choose the best answer to the question based on the passage(s).
                </p>
                <p>
                  All questions in this section are multiple-choice with four answer choices. Each question has a single best answer.
                </p>
              </>
            )}
          </div>

          {/* Tools summary */}
          {isMath && (
            <div className="mt-5 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-3">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5 font-medium text-slate-700">
                  <Calculator className="w-4 h-4 text-blue-700" /> Desmos Calculator Available
                </span>
                <span className="flex items-center gap-1.5 font-medium text-slate-700">
                  <BookOpen className="w-4 h-4 text-amber-600" /> Reference Sheet Available
                </span>
              </div>
              <span className="text-slate-400">Battery: 100%</span>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Bar matching Bluebook */}
      <footer className="h-[60px] px-8 bg-[#e8eef7] border-t border-slate-300 flex items-center justify-between">
        <div className="text-[17px] font-bold text-[#111827]">
          {studentName}
        </div>

        <button
          onClick={onBegin}
          className="h-[38px] px-8 text-[14px] font-bold rounded-full bg-[#2554d7] hover:bg-[#1d46b8] text-white transition-all cursor-pointer shadow-md active:scale-95 flex items-center gap-2"
        >
          <span>Begin {isMath ? 'Math' : 'Module'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </footer>
    </div>
  );
};
