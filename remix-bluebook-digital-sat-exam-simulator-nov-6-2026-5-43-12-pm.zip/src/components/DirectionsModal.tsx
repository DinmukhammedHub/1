import React from 'react';
import { X, Clock, HelpCircle, CheckCircle2 } from 'lucide-react';
import { SectionType } from '../types/sat';

interface DirectionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  sectionType: SectionType;
  moduleNumber: number;
}

export const DirectionsModal: React.FC<DirectionsModalProps> = ({
  isOpen,
  onClose,
  sectionType,
  moduleNumber,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in-50">
      <div className="fixed inset-0" onClick={onClose} />
      <div className="relative w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-300 overflow-hidden z-10 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              {sectionType === 'rw'
                ? `Section 1: Reading and Writing – Module ${moduleNumber}`
                : `Section 2: Math – Module ${moduleNumber}`}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">Official Examination Instructions & Rules</p>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-200 rounded-full cursor-pointer">
            <X className="w-5 h-5 text-slate-600" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-sm text-slate-700 leading-relaxed">
          {sectionType === 'rw' ? (
            <>
              <div className="flex items-start gap-3 p-3.5 bg-blue-50 border border-blue-200 rounded-lg text-blue-900">
                <Clock className="w-5 h-5 shrink-0 text-blue-700 mt-0.5" />
                <div>
                  <div className="font-semibold text-xs uppercase tracking-wider">Timing & Structure</div>
                  <div className="text-xs mt-0.5">
                    <strong>27 questions</strong> • <strong>32 minutes</strong> per module.
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <p>
                  The questions in this section address a number of important reading and writing skills. Each question includes one or more passages, which may also include a table or graph.
                </p>
                <p>
                  Read each passage and question carefully, and then choose the best answer to the question based on the passage(s).
                </p>
                <p>
                  All questions in this section are multiple-choice with four answer choices. Each question has a single best answer.
                </p>
              </div>

              <div className="border-t border-slate-100 pt-3 text-xs text-slate-500 space-y-1.5">
                <div className="font-bold text-slate-700">Digital Testing Tools:</div>
                <p>• <strong>Mark for Review:</strong> Flag questions to return to later in this module.</p>
                <p>• <strong>Option Eliminator:</strong> Cross out answer choices you know are incorrect.</p>
                <p>• <strong>Highlights & Notes:</strong> Select text in passages to highlight or annotate.</p>
                <p>• <strong>Timer:</strong> You can hide the timer at any time, but it will automatically unhide when 5 minutes remain.</p>
              </div>
            </>
          ) : (
            <>
              <div className="flex items-start gap-3 p-3.5 bg-blue-50 border border-blue-200 rounded-lg text-blue-900">
                <Clock className="w-5 h-5 shrink-0 text-blue-700 mt-0.5" />
                <div>
                  <div className="font-semibold text-xs uppercase tracking-wider">Timing & Structure</div>
                  <div className="text-xs mt-0.5">
                    <strong>22 questions</strong> • <strong>35 minutes</strong> per module.
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <p>
                  The questions in this section address a number of important math skills.
                </p>
                <p>
                  Use of a calculator is permitted for all questions. A built-in scientific/graphing calculator is available via the toolbar, or you may bring your own approved calculator.
                </p>
                <p>
                  Unless a question indicates otherwise, you may assume that the domain of any function is the set of all real numbers for which the function is defined.
                </p>
              </div>

              <div className="border-t border-slate-100 pt-3 text-xs text-slate-500 space-y-1.5">
                <div className="font-bold text-slate-700">Student-Produced Responses (Grid-in):</div>
                <p>• For questions without multiple choices, enter your answer directly in the box.</p>
                <p>• Answers can be integers, fractions (e.g., 7/4), or decimals (e.g., 1.75).</p>
                <p>• Do not enter symbols such as dollar signs or percent signs.</p>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors cursor-pointer"
          >
            Continue Test
          </button>
        </div>
      </div>
    </div>
  );
};
