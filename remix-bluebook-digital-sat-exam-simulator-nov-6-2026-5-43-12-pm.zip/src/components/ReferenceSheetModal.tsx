import React from 'react';
import { X } from 'lucide-react';

interface ReferenceSheetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReferenceSheetModal: React.FC<ReferenceSheetModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in-50">
      <div className="fixed inset-0" onClick={onClose} />
      <div className="relative w-full max-w-3xl bg-white rounded-xl shadow-2xl border border-slate-300 overflow-hidden z-10 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-[#002f6c] text-white">
          <div>
            <h3 className="text-base font-bold">SAT Reference Sheet</h3>
            <p className="text-xs text-blue-100">Official mathematical formulas provided on test day</p>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-white/20 rounded cursor-pointer">
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-800">
          {/* Top Row: Basic 2D Geometry */}
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
              Area & Circumference
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
              {/* Circle */}
              <div className="p-3 border border-slate-200 rounded-lg bg-slate-50 flex flex-col items-center">
                <svg className="w-16 h-16 text-slate-700" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="35" fill="none" stroke="currentColor" strokeWidth="2" />
                  <line x1="50" y1="50" x2="85" y2="50" stroke="#2563eb" strokeWidth="2" />
                  <text x="65" y="44" fontSize="12" fill="#2563eb" fontStyle="italic">r</text>
                </svg>
                <div className="mt-2 font-serif text-sm font-semibold">
                  A = πr²<br />C = 2πr
                </div>
              </div>

              {/* Rectangle */}
              <div className="p-3 border border-slate-200 rounded-lg bg-slate-50 flex flex-col items-center">
                <svg className="w-16 h-16 text-slate-700" viewBox="0 0 100 100">
                  <rect x="20" y="30" width="60" height="40" fill="none" stroke="currentColor" strokeWidth="2" />
                  <text x="48" y="24" fontSize="12" fill="#2563eb" fontStyle="italic">ℓ</text>
                  <text x="84" y="54" fontSize="12" fill="#2563eb" fontStyle="italic">w</text>
                </svg>
                <div className="mt-2 font-serif text-sm font-semibold">
                  A = ℓw
                </div>
              </div>

              {/* Triangle */}
              <div className="p-3 border border-slate-200 rounded-lg bg-slate-50 flex flex-col items-center">
                <svg className="w-16 h-16 text-slate-700" viewBox="0 0 100 100">
                  <polygon points="20,75 80,75 50,25" fill="none" stroke="currentColor" strokeWidth="2" />
                  <line x1="50" y1="25" x2="50" y2="75" stroke="#2563eb" strokeDasharray="3 3" strokeWidth="1.5" />
                  <text x="54" y="55" fontSize="12" fill="#2563eb" fontStyle="italic">h</text>
                  <text x="48" y="90" fontSize="12" fill="#2563eb" fontStyle="italic">b</text>
                </svg>
                <div className="mt-2 font-serif text-sm font-semibold">
                  A = ½bh
                </div>
              </div>

              {/* Right Triangle */}
              <div className="p-3 border border-slate-200 rounded-lg bg-slate-50 flex flex-col items-center">
                <svg className="w-16 h-16 text-slate-700" viewBox="0 0 100 100">
                  <polygon points="25,75 75,75 25,25" fill="none" stroke="currentColor" strokeWidth="2" />
                  <text x="12" y="54" fontSize="12" fill="#2563eb" fontStyle="italic">a</text>
                  <text x="48" y="90" fontSize="12" fill="#2563eb" fontStyle="italic">b</text>
                  <text x="56" y="46" fontSize="12" fill="#2563eb" fontStyle="italic">c</text>
                </svg>
                <div className="mt-2 font-serif text-sm font-semibold">
                  c² = a² + b²
                </div>
              </div>
            </div>
          </div>

          {/* Special Right Triangles */}
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
              Special Right Triangles
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 border border-slate-200 rounded-lg bg-slate-50 flex items-center justify-around">
                <div className="text-center font-serif text-sm">
                  <span className="font-bold text-slate-900 block mb-1">30° - 60° - 90°</span>
                  Sides: <span className="font-mono text-blue-700">x, x√3, 2x</span>
                </div>
              </div>
              <div className="p-4 border border-slate-200 rounded-lg bg-slate-50 flex items-center justify-around">
                <div className="text-center font-serif text-sm">
                  <span className="font-bold text-slate-900 block mb-1">45° - 45° - 90°</span>
                  Sides: <span className="font-mono text-blue-700">s, s, s√2</span>
                </div>
              </div>
            </div>
          </div>

          {/* 3D Volumes */}
          <div>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
              Volumes
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-center text-xs">
              <div className="p-2.5 border border-slate-200 rounded-lg bg-slate-50">
                <div className="font-bold text-slate-900 mb-1">Rectangular Prism</div>
                <div className="font-serif text-sm font-semibold">V = ℓwh</div>
              </div>
              <div className="p-2.5 border border-slate-200 rounded-lg bg-slate-50">
                <div className="font-bold text-slate-900 mb-1">Right Cylinder</div>
                <div className="font-serif text-sm font-semibold">V = πr²h</div>
              </div>
              <div className="p-2.5 border border-slate-200 rounded-lg bg-slate-50">
                <div className="font-bold text-slate-900 mb-1">Sphere</div>
                <div className="font-serif text-sm font-semibold">V = ⁴⁄₃πr³</div>
              </div>
              <div className="p-2.5 border border-slate-200 rounded-lg bg-slate-50">
                <div className="font-bold text-slate-900 mb-1">Right Cone</div>
                <div className="font-serif text-sm font-semibold">V = ⅓πr²h</div>
              </div>
              <div className="p-2.5 border border-slate-200 rounded-lg bg-slate-50">
                <div className="font-bold text-slate-900 mb-1">Pyramid</div>
                <div className="font-serif text-sm font-semibold">V = ⅓ℓwh</div>
              </div>
            </div>
          </div>

          {/* Properties of Circles & Triangles */}
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-950 space-y-1.5 leading-relaxed">
            <p>• The number of degrees of arc in a circle is <strong>360</strong>.</p>
            <p>• The number of radians of arc in a circle is <strong>2π</strong>.</p>
            <p>• The sum of the measures in degrees of the angles of a triangle is <strong>180</strong>.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
