import React from 'react';

interface SatGraphicProps {
  graphicType?: string;
}

export const SatGraphic: React.FC<SatGraphicProps> = ({ graphicType }) => {
  if (!graphicType) return null;

  switch (graphicType) {
    // RW1 Q11: Volcanoes Bar Chart
    case 'volcanoes-chart':
      return (
        <div className="my-4 p-4 border border-slate-300 rounded bg-white max-w-[420px] mx-auto text-center font-sans">
          <div className="text-xs font-semibold text-slate-800 mb-1 leading-snug">
            Volcanoes Active since 1800 and<br />since 1960 in Two Countries
          </div>
          <svg viewBox="0 0 320 220" className="w-full h-auto max-h-[220px] mx-auto">
            {/* Y axis and gridlines */}
            <line x1="50" y1="20" x2="50" y2="160" stroke="#000" strokeWidth="1.2" />
            <line x1="50" y1="160" x2="290" y2="160" stroke="#000" strokeWidth="1.2" />
            
            {/* Y ticks & labels */}
            {[0, 2, 4, 6, 8, 10, 12, 14, 16, 18].map((val) => {
              const y = 160 - (val / 18) * 140;
              return (
                <g key={val}>
                  <line x1="46" y1={y} x2="290" y2={y} stroke="#e2e8f0" strokeWidth="0.8" />
                  <line x1="46" y1={y} x2="50" y2={y} stroke="#000" strokeWidth="1" />
                  <text x="42" y={y + 3.5} textAnchor="end" fontSize="10" fill="#333" fontFamily="sans-serif">
                    {val}
                  </text>
                </g>
              );
            })}

            {/* Y label */}
            <text
              transform="rotate(-90)"
              x="-90"
              y="16"
              textAnchor="middle"
              fontSize="10"
              fontFamily="sans-serif"
              fill="#111"
            >
              Number of active volcanoes
            </text>

            {/* Bars for 'active since 1800': Portugal=5, Ecuador=17 */}
            {/* Portugal (5) -> height (5/18)*140 = 38.89 */}
            <rect x="80" y={160 - (5 / 18) * 140} width="28" height={(5 / 18) * 140} fill="#c4c4c4" stroke="#000" strokeWidth="1" />
            {/* Ecuador (17) -> height (17/18)*140 = 132.2 */}
            <rect x="108" y={160 - (17 / 18) * 140} width="28" height={(17 / 18) * 140} fill="#333333" stroke="#000" strokeWidth="1" />

            {/* Bars for 'active since 1960': Portugal=1, Ecuador=11 */}
            {/* Portugal (1) -> height (1/18)*140 = 7.78 */}
            <rect x="190" y={160 - (1 / 18) * 140} width="28" height={(1 / 18) * 140} fill="#c4c4c4" stroke="#000" strokeWidth="1" />
            {/* Ecuador (11) -> height (11/18)*140 = 85.56 */}
            <rect x="218" y={160 - (11 / 18) * 140} width="28" height={(11 / 18) * 140} fill="#333333" stroke="#000" strokeWidth="1" />

            {/* X Labels */}
            <text x="108" y="178" textAnchor="end" transform="rotate(-35 108 178)" fontSize="10" fill="#222">
              active since 1800
            </text>
            <text x="218" y="178" textAnchor="end" transform="rotate(-35 218 178)" fontSize="10" fill="#222">
              active since 1960
            </text>
          </svg>
          <div className="text-[11px] font-sans text-slate-700 mt-1 mb-2">Year</div>
          <div className="flex items-center justify-center gap-4 text-xs font-sans border border-slate-400 py-1 px-3 w-fit mx-auto bg-slate-50">
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 bg-[#c4c4c4] border border-black inline-block" />
              <span>Portugal</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 bg-[#333333] border border-black inline-block" />
              <span>Ecuador</span>
            </div>
          </div>
        </div>
      );

    // RW1 Q13: Tax Penalties Bar Chart
    case 'tax-penalties-chart':
      return (
        <div className="my-4 p-4 border border-slate-300 rounded bg-white max-w-[440px] mx-auto text-center font-sans">
          <div className="text-xs font-semibold text-slate-800 mb-1 leading-snug">
            Tax Penalties Assessed on Private<br />Foundations That Filed Form 4720,<br />by Reason, 2003–2005
          </div>
          <svg viewBox="0 0 350 240" className="w-full h-auto max-h-[240px] mx-auto">
            <line x1="55" y1="20" x2="55" y2="170" stroke="#000" strokeWidth="1.2" />
            <line x1="55" y1="170" x2="330" y2="170" stroke="#000" strokeWidth="1.2" />

            {[0, 10, 20, 30, 40, 50, 60, 70, 80].map((val) => {
              const y = 170 - (val / 80) * 150;
              return (
                <g key={val}>
                  <line x1="51" y1={y} x2="330" y2={y} stroke="#e2e8f0" strokeWidth="0.8" />
                  <line x1="51" y1={y} x2="55" y2={y} stroke="#000" strokeWidth="1" />
                  <text x="47" y={y + 3.5} textAnchor="end" fontSize="10" fill="#333" fontFamily="sans-serif">
                    {val}
                  </text>
                </g>
              );
            })}

            <text
              transform="rotate(-90)"
              x="-95"
              y="18"
              textAnchor="middle"
              fontSize="10"
              fontFamily="sans-serif"
              fill="#111"
            >
              Percentage of total penalty
            </text>

            {/* Reason 1: self-dealing (2003: 10%, 2004: 10%, 2005: 40%) */}
            <rect x="70" y={170 - (10 / 80) * 150} width="14" height={(10 / 80) * 150} fill="#c4c4c4" stroke="#000" strokeWidth="0.8" />
            <rect x="84" y={170 - (10 / 80) * 150} width="14" height={(10 / 80) * 150} fill="#888888" stroke="#000" strokeWidth="0.8" />
            <rect x="98" y={170 - (40 / 80) * 150} width="14" height={(40 / 80) * 150} fill="#111111" stroke="#000" strokeWidth="0.8" />

            {/* Reason 2: undistributed income (2003: 75%, 2004: 78%, 2005: 55%) */}
            <rect x="135" y={170 - (75 / 80) * 150} width="14" height={(75 / 80) * 150} fill="#c4c4c4" stroke="#000" strokeWidth="0.8" />
            <rect x="149" y={170 - (78 / 80) * 150} width="14" height={(78 / 80) * 150} fill="#888888" stroke="#000" strokeWidth="0.8" />
            <rect x="163" y={170 - (55 / 80) * 150} width="14" height={(55 / 80) * 150} fill="#111111" stroke="#000" strokeWidth="0.8" />

            {/* Reason 3: taxable expenditures (2003: 5%, 2004: 12%, 2005: 3%) */}
            <rect x="200" y={170 - (5 / 80) * 150} width="14" height={(5 / 80) * 150} fill="#c4c4c4" stroke="#000" strokeWidth="0.8" />
            <rect x="214" y={170 - (12 / 80) * 150} width="14" height={(12 / 80) * 150} fill="#888888" stroke="#000" strokeWidth="0.8" />
            <rect x="228" y={170 - (3 / 80) * 150} width="14" height={(3 / 80) * 150} fill="#111111" stroke="#000" strokeWidth="0.8" />

            {/* Reason 4: excess business holdings (2003: 2%, 2004: 1%, 2005: 1%) */}
            <rect x="265" y={170 - (2 / 80) * 150} width="14" height={(2 / 80) * 150} fill="#c4c4c4" stroke="#000" strokeWidth="0.8" />
            <rect x="279" y={170 - (1 / 80) * 150} width="14" height={(1 / 80) * 150} fill="#888888" stroke="#000" strokeWidth="0.8" />
            <rect x="293" y={170 - (1 / 80) * 150} width="14" height={(1 / 80) * 150} fill="#111111" stroke="#000" strokeWidth="0.8" />

            {/* Labels angled */}
            <text x="88" y="185" textAnchor="end" transform="rotate(-35 88 185)" fontSize="9" fill="#222">self-dealing</text>
            <text x="153" y="185" textAnchor="end" transform="rotate(-35 153 185)" fontSize="9" fill="#222">undistributed income</text>
            <text x="218" y="185" textAnchor="end" transform="rotate(-35 218 185)" fontSize="9" fill="#222">taxable expenditures</text>
            <text x="283" y="185" textAnchor="end" transform="rotate(-35 283 185)" fontSize="9" fill="#222">excess business holdings</text>
          </svg>
          <div className="text-[11px] font-sans text-slate-700 mt-1 mb-2">Reason for tax penalty</div>
          <div className="flex items-center justify-center gap-3 text-xs font-sans border border-slate-400 py-1 px-3 w-fit mx-auto bg-slate-50">
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 bg-[#c4c4c4] border border-black inline-block" />
              <span>2003</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 bg-[#888888] border border-black inline-block" />
              <span>2004</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 bg-[#111111] border border-black inline-block" />
              <span>2005</span>
            </div>
          </div>
        </div>
      );

    // RW2 Hard Q10: T-values Table
    case 'tvalues-table':
      return (
        <div className="my-4 max-w-[420px] mx-auto font-sans">
          <div className="text-xs font-semibold text-slate-800 text-center mb-2 leading-snug">
            T-values and P-values for the Relationship between Recording Position and Change in Song Characteristics
          </div>
          <table className="w-full border-collapse border border-slate-400 text-xs">
            <thead>
              <tr className="bg-slate-100 border-b border-slate-400">
                <th className="p-2 border-r border-slate-400 text-left font-semibold">Song characteristic</th>
                <th className="p-2 border-r border-slate-400 text-center font-semibold">T-value</th>
                <th className="p-2 text-center font-semibold">P-value</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-slate-300">
                <td className="p-2 border-r border-slate-300">Change in peak frequency (Hz)</td>
                <td className="p-2 border-r border-slate-300 text-center font-mono">-1.0</td>
                <td className="p-2 text-center font-mono">0.4</td>
              </tr>
              <tr className="border-b border-slate-300">
                <td className="p-2 border-r border-slate-300">Change in song rate (songs/min)</td>
                <td className="p-2 border-r border-slate-300 text-center font-mono">-2.2</td>
                <td className="p-2 text-center font-mono">0.03</td>
              </tr>
              <tr>
                <td className="p-2 border-r border-slate-300">Change in song duration (s)</td>
                <td className="p-2 border-r border-slate-300 text-center font-mono">-3.2</td>
                <td className="p-2 text-center font-mono">0.002</td>
              </tr>
            </tbody>
          </table>
        </div>
      );

    // RW2 Hard Q12: Summits Table
    case 'summits-table':
      return (
        <div className="my-4 max-w-[460px] mx-auto font-sans">
          <div className="text-xs font-semibold text-slate-800 text-center mb-2 leading-snug">
            Highest Major Summits in India
          </div>
          <table className="w-full border-collapse border border-slate-400 text-xs">
            <thead>
              <tr className="bg-slate-100 border-b border-slate-400">
                <th className="p-2 border-r border-slate-400 text-left font-semibold">Summit</th>
                <th className="p-2 border-r border-slate-400 text-center font-semibold">Elevation (meters)</th>
                <th className="p-2 border-r border-slate-400 text-left font-semibold">Mountain range</th>
                <th className="p-2 text-center font-semibold">Prominence (meters)</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-slate-300">
                <td className="p-2 border-r border-slate-300 font-medium">Rimo I</td>
                <td className="p-2 border-r border-slate-300 text-center font-mono">7,385</td>
                <td className="p-2 border-r border-slate-300">Rimo Karakoram</td>
                <td className="p-2 text-center font-mono">1,438</td>
              </tr>
              <tr className="border-b border-slate-300">
                <td className="p-2 border-r border-slate-300 font-medium">Nanda Devi</td>
                <td className="p-2 border-r border-slate-300 text-center font-mono">7,816</td>
                <td className="p-2 border-r border-slate-300">Himalayas</td>
                <td className="p-2 text-center font-mono">3,139</td>
              </tr>
              <tr className="border-b border-slate-300">
                <td className="p-2 border-r border-slate-300 font-medium">Panchchuli II</td>
                <td className="p-2 border-r border-slate-300 text-center font-mono">6,904</td>
                <td className="p-2 border-r border-slate-300">Garhwal Himalaya</td>
                <td className="p-2 text-center font-mono">1,614</td>
              </tr>
              <tr className="border-b border-slate-300">
                <td className="p-2 border-r border-slate-300 font-medium">Saser Kangri I / K22</td>
                <td className="p-2 border-r border-slate-300 text-center font-mono">7,672</td>
                <td className="p-2 border-r border-slate-300">Saser Karakoram</td>
                <td className="p-2 text-center font-mono">2,304</td>
              </tr>
              <tr>
                <td className="p-2 border-r border-slate-300 font-medium">Langpo</td>
                <td className="p-2 border-r border-slate-300 text-center font-mono">6,965</td>
                <td className="p-2 border-r border-slate-300">Sikkim Himalaya</td>
                <td className="p-2 text-center font-mono">560</td>
              </tr>
            </tbody>
          </table>
        </div>
      );

    // Math 1 Q2: Kayla's Histogram
    case 'math-kayla-histogram':
      return (
        <div className="my-4 p-4 border border-slate-300 rounded bg-white max-w-[340px] mx-auto text-center font-sans">
          <svg viewBox="0 0 260 200" className="w-full h-auto max-h-[200px] mx-auto">
            {/* Gridlines */}
            {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((v) => {
              const y = 160 - (v / 8) * 140;
              return (
                <g key={v}>
                  <line x1="50" y1={y} x2="230" y2={y} stroke="#e2e8f0" strokeWidth="0.8" />
                  <line x1="46" y1={y} x2="50" y2={y} stroke="#000" strokeWidth="1" />
                  <text x="42" y={y + 3.5} textAnchor="end" fontSize="10" fill="#333">
                    {v}
                  </text>
                </g>
              );
            })}
            <line x1="50" y1="20" x2="50" y2="160" stroke="#000" strokeWidth="1.2" />
            <line x1="50" y1="160" x2="230" y2="160" stroke="#000" strokeWidth="1.2" />

            <text transform="rotate(-90)" x="-90" y="16" textAnchor="middle" fontSize="10" fill="#111">
              Frequency
            </text>

            {/* Bars: each width 32 */}
            {/* 51-53: 6 */}
            <rect x="58" y={160 - (6 / 8) * 140} width="32" height={(6 / 8) * 140} fill="#94a3b8" stroke="#000" strokeWidth="1" />
            {/* 53-55: 4 */}
            <rect x="90" y={160 - (4 / 8) * 140} width="32" height={(4 / 8) * 140} fill="#94a3b8" stroke="#000" strokeWidth="1" />
            {/* 55-57: 5 */}
            <rect x="122" y={160 - (5 / 8) * 140} width="32" height={(5 / 8) * 140} fill="#94a3b8" stroke="#000" strokeWidth="1" />
            {/* 57-59: 8 */}
            <rect x="154" y={160 - (8 / 8) * 140} width="32" height={(8 / 8) * 140} fill="#94a3b8" stroke="#000" strokeWidth="1" />
            {/* 59-61: 2 */}
            <rect x="186" y={160 - (2 / 8) * 140} width="32" height={(2 / 8) * 140} fill="#94a3b8" stroke="#000" strokeWidth="1" />

            {/* X ticks */}
            {[
              { val: 51, x: 58 },
              { val: 53, x: 90 },
              { val: 55, x: 122 },
              { val: 57, x: 154 },
              { val: 59, x: 186 },
              { val: 61, x: 218 },
            ].map(({ val, x }) => (
              <g key={val}>
                <line x1={x} y1="160" x2={x} y2="164" stroke="#000" strokeWidth="1" />
                <text x={x} y="176" textAnchor="middle" fontSize="10" fill="#222">
                  {val}
                </text>
              </g>
            ))}
          </svg>
          <div className="text-[11px] font-sans text-slate-700 mt-1">Height (in)</div>
        </div>
      );

    // Math 1 Q5: Similar Triangles ABC and A'B'C'
    case 'math-similar-triangles':
      return (
        <div className="my-4 p-4 border border-slate-300 rounded bg-white max-w-[380px] mx-auto text-center font-sans">
          <svg viewBox="0 0 340 130" className="w-full h-auto max-h-[130px] mx-auto">
            {/* Triangle ABC */}
            <polygon points="30,100 80,40 120,100" fill="none" stroke="#000" strokeWidth="1.5" />
            <text x="20" y="105" fontSize="12" fontStyle="italic" fill="#000">A</text>
            <text x="78" y="32" fontSize="12" fontStyle="italic" fill="#000">B</text>
            <text x="125" y="105" fontSize="12" fontStyle="italic" fill="#000">C</text>

            {/* Triangle A'B'C' (dilated by 3) */}
            <polygon points="160,100 235,15 310,100" fill="none" stroke="#000" strokeWidth="1.5" />
            <text x="145" y="105" fontSize="12" fontStyle="italic" fill="#000">A′</text>
            <text x="233" y="10" fontSize="12" fontStyle="italic" fill="#000">B′</text>
            <text x="315" y="105" fontSize="12" fontStyle="italic" fill="#000">C′</text>
          </svg>
          <div className="text-[11px] italic text-slate-500 mt-1">Note: Figures not drawn to scale.</div>
        </div>
      );

    // Math 1 Q10: Scatterplot
    case 'math-scatterplot-1':
      return (
        <div className="my-4 p-4 border border-slate-300 rounded bg-white max-w-[340px] mx-auto text-center font-sans">
          <svg viewBox="0 0 240 220" className="w-full h-auto max-h-[220px] mx-auto">
            {/* Grid */}
            {[0, 5, 10, 15, 20, 25].map((yVal) => {
              const y = 180 - (yVal / 25) * 160;
              return (
                <g key={yVal}>
                  <line x1="40" y1={y} x2="220" y2={y} stroke="#cbd5e1" strokeWidth="0.8" />
                  <text x="35" y={y + 3.5} textAnchor="end" fontSize="10" fill="#333">{yVal}</text>
                </g>
              );
            })}
            {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((xVal) => {
              const x = 40 + (xVal / 10) * 180;
              return (
                <g key={xVal}>
                  <line x1={x} y1="20" x2={x} y2="180" stroke="#cbd5e1" strokeWidth="0.8" />
                  {xVal > 0 && <text x={x} y="195" textAnchor="middle" fontSize="10" fill="#333">{xVal}</text>}
                </g>
              );
            })}
            <line x1="40" y1="15" x2="40" y2="180" stroke="#000" strokeWidth="1.2" />
            <line x1="40" y1="180" x2="225" y2="180" stroke="#000" strokeWidth="1.2" />

            <text x="40" y="10" fontSize="11" fontStyle="italic" fill="#000">y</text>
            <text x="230" y="184" fontSize="11" fontStyle="italic" fill="#000">x</text>

            {/* Data points */}
            {[
              [1, 1], [2, 5], [3, 7], [4, 7], [5, 13], [6, 10], [7, 16], [8, 19], [9, 21], [10, 22.5]
            ].map(([px, py], i) => (
              <circle key={i} cx={40 + (px / 10) * 180} cy={180 - (py / 25) * 160} r="3.5" fill="#000" />
            ))}
          </svg>
        </div>
      );

    // Math 1 Q18: 45-45-90 Triangle ABC
    case 'math-45-45-triangle':
      return (
        <div className="my-4 p-4 border border-slate-300 rounded bg-white max-w-[300px] mx-auto text-center font-sans">
          <svg viewBox="0 0 200 180" className="w-full h-auto max-h-[180px] mx-auto">
            {/* Right triangle: B at bottom-left (50, 140), C at top-left (50, 40), A at bottom-right (150, 140) */}
            <polygon points="50,140 50,40 150,140" fill="none" stroke="#000" strokeWidth="1.5" />
            {/* Right angle mark at B */}
            <polyline points="50,128 62,128 62,140" fill="none" stroke="#000" strokeWidth="1.2" />
            
            <text x="40" y="152" fontSize="12" fontStyle="italic" fill="#000">B</text>
            <text x="42" y="32" fontSize="12" fontStyle="italic" fill="#000">C</text>
            <text x="156" y="152" fontSize="12" fontStyle="italic" fill="#000">A</text>

            <text x="56" y="58" fontSize="10" fill="#333">45°</text>
            <text x="122" y="136" fontSize="10" fill="#333">45°</text>

            {/* Hypotenuse label x */}
            <text x="110" y="85" fontSize="11" fontStyle="italic" fill="#000">x</text>
          </svg>
        </div>
      );

    // Math 1 Q19: Shaded region y > -6
    case 'math-shaded-plane':
      return (
        <div className="my-4 p-4 border border-slate-300 rounded bg-white max-w-[300px] mx-auto text-center font-sans">
          <svg viewBox="0 0 240 240" className="w-full h-auto max-h-[220px] mx-auto">
            {/* Grid */}
            {[-8, -6, -4, -2, 0, 2, 4, 6, 8].map((v) => {
              const x = 120 + (v / 8) * 90;
              return (
                <line key={v} x1={x} y1="20" x2={x} y2="220" stroke="#cbd5e1" strokeWidth="0.8" />
              );
            })}
            {[-10, -8, -6, -4, -2, 0, 2].map((v) => {
              const y = 50 - (v / 8) * 90;
              return (
                <line key={v} x1="30" y1={y} x2="210" y2={y} stroke="#cbd5e1" strokeWidth="0.8" />
              );
            })}

            {/* Shaded area above y = -6 (which is y < 117.5 in SVG coordinates) */}
            <rect x="30" y="20" width="180" height="97.5" fill="#94a3b8" fillOpacity="0.5" />

            {/* Dashed line at y = -6 */}
            <line x1="30" y1="117.5" x2="210" y2="117.5" stroke="#000" strokeWidth="2" strokeDasharray="4 3" />

            {/* Axes */}
            <line x1="120" y1="15" x2="120" y2="225" stroke="#000" strokeWidth="1.2" />
            <line x1="25" y1="50" x2="215" y2="50" stroke="#000" strokeWidth="1.2" />

            {/* Labels */}
            <text x="120" y="10" fontSize="11" fontStyle="italic" fill="#000">y</text>
            <text x="220" y="54" fontSize="11" fontStyle="italic" fill="#000">x</text>

            {/* X Numbers */}
            {[-8, -6, -4, -2, 2, 4, 6, 8].map((v) => (
              <text key={v} x={120 + (v / 8) * 90} y="62" textAnchor="middle" fontSize="9" fill="#000">
                {v}
              </text>
            ))}
            {/* Y Numbers */}
            {[2, -2, -4, -6, -8, -10].map((v) => (
              <text key={v} x="114" y={50 - (v / 8) * 90 + 3.5} textAnchor="end" fontSize="9" fill="#000">
                {v}
              </text>
            ))}
          </svg>
        </div>
      );

    // Math 2 Hard Q1: Parallel Lines with Transversal
    case 'math-parallel-lines':
      return (
        <div className="my-4 p-4 border border-slate-300 rounded bg-white max-w-[340px] mx-auto text-center font-sans">
          <svg viewBox="0 0 280 160" className="w-full h-auto max-h-[160px] mx-auto">
            {/* Line l */}
            <line x1="30" y1="50" x2="230" y2="50" stroke="#000" strokeWidth="1.5" />
            <text x="240" y="54" fontSize="12" fontStyle="italic" fill="#000">l</text>

            {/* Line k */}
            <line x1="30" y1="110" x2="230" y2="110" stroke="#000" strokeWidth="1.5" />
            <text x="240" y="114" fontSize="12" fontStyle="italic" fill="#000">k</text>

            {/* Transversal line t */}
            <line x1="70" y1="15" x2="200" y2="145" stroke="#000" strokeWidth="1.5" />
            <text x="60" y="15" fontSize="12" fontStyle="italic" fill="#000">t</text>

            {/* Angle x°: upper-right at intersection with l */}
            <text x="122" y="42" fontSize="10" fill="#000">x°</text>

            {/* Angle y°: upper-left at intersection with k */}
            <text x="145" y="104" fontSize="10" fill="#000">y°</text>
          </svg>
          <div className="text-[11px] italic text-slate-500 mt-1">Note: Figure not drawn to scale.</div>
        </div>
      );

    // Math 2 Hard Q2: Garden table
    case 'math-garden-table':
      return (
        <div className="my-4 max-w-[300px] mx-auto font-sans">
          <table className="w-full border-collapse border border-slate-400 text-xs">
            <thead>
              <tr className="bg-slate-100 border-b border-slate-400">
                <th className="p-2 border-r border-slate-400 text-center font-semibold">Area (square feet)</th>
                <th className="p-2 text-center font-semibold">Water (gallons)</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-slate-300">
                <td className="p-2 border-r border-slate-300 text-center font-mono">1,040</td>
                <td className="p-2 text-center font-mono">2,496</td>
              </tr>
              <tr className="border-b border-slate-300">
                <td className="p-2 border-r border-slate-300 text-center font-mono">1,560</td>
                <td className="p-2 text-center font-mono">3,744</td>
              </tr>
              <tr>
                <td className="p-2 border-r border-slate-300 text-center font-mono">2,080</td>
                <td className="p-2 text-center font-mono">4,992</td>
              </tr>
            </tbody>
          </table>
        </div>
      );

    // Math 2 Hard Q7: Scatterplot Residuals
    case 'math-scatterplot-residuals':
      return (
        <div className="my-4 p-4 border border-slate-300 rounded bg-white max-w-[340px] mx-auto text-center font-sans">
          <svg viewBox="0 0 240 220" className="w-full h-auto max-h-[220px] mx-auto">
            {/* Grid */}
            {[0, 2, 4, 6, 8, 10].map((yVal) => {
              const y = 180 - (yVal / 10) * 160;
              return (
                <g key={yVal}>
                  <line x1="40" y1={y} x2="220" y2={y} stroke="#cbd5e1" strokeWidth="0.8" />
                  <text x="35" y={y + 3.5} textAnchor="end" fontSize="10" fill="#333">{yVal}</text>
                </g>
              );
            })}
            {[0, 2, 4, 6, 8, 10].map((xVal) => {
              const x = 40 + (xVal / 10) * 180;
              return (
                <g key={xVal}>
                  <line x1={x} y1="20" x2={x} y2="180" stroke="#cbd5e1" strokeWidth="0.8" />
                  {xVal > 0 && <text x={x} y="195" textAnchor="middle" fontSize="10" fill="#333">{xVal}</text>}
                </g>
              );
            })}
            <line x1="40" y1="15" x2="40" y2="180" stroke="#000" strokeWidth="1.2" />
            <line x1="40" y1="180" x2="225" y2="180" stroke="#000" strokeWidth="1.2" />

            <text x="40" y="10" fontSize="11" fontStyle="italic" fill="#000">y</text>
            <text x="230" y="184" fontSize="11" fontStyle="italic" fill="#000">x</text>

            {/* Line of best fit */}
            <line x1="40" y1="95" x2="220" y2="175" stroke="#000" strokeWidth="1.5" />

            {/* 9 Points from screenshot: 6 above line, 3 below line */}
            {[
              [1, 5.2],
              [2, 4.8],
              [3, 4.4],
              [4, 4.8],
              [5, 4.8],
              [6, 2.5],
              [7, 2.2],
              [8, 1.3],
              [9, 2.1],
            ].map(([px, py], i) => (
              <circle key={i} cx={40 + (px / 10) * 180} cy={180 - (py / 10) * 160} r="3.5" fill="#000" />
            ))}
          </svg>
        </div>
      );

    // Math 2 Hard Q15: Triangle with angles r° and s°
    case 'math-triangle-rs':
      return (
        <div className="my-4 p-4 border border-slate-300 rounded bg-white max-w-[300px] mx-auto text-center font-sans">
          <svg viewBox="0 0 220 180" className="w-full h-auto max-h-[180px] mx-auto">
            {/* Right triangle: top angle r°, bottom-right angle s° */}
            <polygon points="50,150 50,30 190,150" fill="none" stroke="#000" strokeWidth="1.5" />
            {/* Right angle mark at (50, 150) */}
            <polyline points="50,138 62,138 62,150" fill="none" stroke="#000" strokeWidth="1.2" />

            {/* Angle r° at top */}
            <text x="56" y="52" fontSize="11" fill="#000">r°</text>

            {/* Angle s° at bottom-right */}
            <text x="160" y="146" fontSize="11" fill="#000">s°</text>
          </svg>
          <div className="text-[11px] italic text-slate-500 mt-1">Note: Figure not drawn to scale.</div>
        </div>
      );

    // Math 2 Hard Q16: Melatonin Gamers Table
    case 'math-gamers-table':
      return (
        <div className="my-4 max-w-[340px] mx-auto font-sans">
          <table className="w-full border-collapse border border-slate-400 text-xs">
            <thead>
              <tr className="bg-slate-100 border-b border-slate-400">
                <th className="p-2 border-r border-slate-400 text-left font-semibold">Country</th>
                <th className="p-2 text-center font-semibold">Number of gamers</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-slate-300">
                <td className="p-2 border-r border-slate-300">Sweden</td>
                <td className="p-2 text-center font-mono">25</td>
              </tr>
              <tr className="border-b border-slate-300">
                <td className="p-2 border-r border-slate-300">South Korea</td>
                <td className="p-2 text-center font-mono">49</td>
              </tr>
              <tr>
                <td className="p-2 border-r border-slate-300">United States</td>
                <td className="p-2 text-center font-mono">53</td>
              </tr>
            </tbody>
          </table>
        </div>
      );

    // Math 2 Hard Q17: Line segment graph on xy-plane
    case 'math-line-segment':
      return (
        <div className="my-4 p-4 border border-slate-300 rounded bg-white max-w-[320px] mx-auto text-center font-sans">
          <svg viewBox="0 0 240 240" className="w-full h-auto max-h-[220px] mx-auto">
            {/* Grid */}
            {[-8, -6, -4, -2, 0, 2, 4, 6, 8].map((v) => {
              const x = 120 + (v / 8) * 85;
              return (
                <line key={v} x1={x} y1="20" x2={x} y2="210" stroke="#cbd5e1" strokeWidth="0.8" />
              );
            })}
            {[0, 2, 4, 6, 8, 10, 12].map((v) => {
              const y = 210 - (v / 12) * 190;
              return (
                <line key={v} x1="35" y1={y} x2="205" y2={y} stroke="#cbd5e1" strokeWidth="0.8" />
              );
            })}

            {/* Axes */}
            <line x1="120" y1="15" x2="120" y2="215" stroke="#000" strokeWidth="1.2" />
            <line x1="30" y1="210" x2="210" y2="210" stroke="#000" strokeWidth="1.2" />

            <text x="120" y="10" fontSize="11" fontStyle="italic" fill="#000">y</text>
            <text x="215" y="214" fontSize="11" fontStyle="italic" fill="#000">x</text>

            {/* X Numbers */}
            {[-8, -6, -4, -2, 2, 4, 6, 8].map((v) => (
              <text key={v} x={120 + (v / 8) * 85} y="222" textAnchor="middle" fontSize="9" fill="#000">
                {v}
              </text>
            ))}
            {/* Y Numbers */}
            {[2, 4, 6, 8, 10, 12].map((v) => (
              <text key={v} x="114" y={210 - (v / 12) * 190 + 3.5} textAnchor="end" fontSize="9" fill="#000">
                {v}
              </text>
            ))}

            {/* Segment from (-6, 5) to (2, 11) */}
            <line
              x1={120 + (-6 / 8) * 85}
              y1={210 - (5 / 12) * 190}
              x2={120 + (2 / 8) * 85}
              y2={210 - (11 / 12) * 190}
              stroke="#000"
              strokeWidth="2.2"
            />
            {/* Dots at endpoints */}
            <circle cx={120 + (-6 / 8) * 85} cy={210 - (5 / 12) * 190} r="4" fill="#000" />
            <circle cx={120 + (2 / 8) * 85} cy={210 - (11 / 12) * 190} r="4" fill="#000" />
          </svg>
        </div>
      );

    // Math 2 Hard Q19: Line y = g(x) - 17
    case 'math-linear-g':
      return (
        <div className="my-4 p-4 border border-slate-300 rounded bg-white max-w-[320px] mx-auto text-center font-sans">
          <svg viewBox="0 0 240 240" className="w-full h-auto max-h-[220px] mx-auto">
            {/* Grid */}
            {[-4, -2, 0, 2, 4].map((v) => {
              const x = 120 + (v / 4) * 80;
              return (
                <line key={v} x1={x} y1="20" x2={x} y2="220" stroke="#cbd5e1" strokeWidth="0.8" />
              );
            })}
            {[-10, -8, -6, -4, -2, 0].map((v) => {
              const y = 40 - (v / 10) * 160;
              return (
                <line key={v} x1="40" y1={y} x2="200" y2={y} stroke="#cbd5e1" strokeWidth="0.8" />
              );
            })}

            {/* Axes */}
            <line x1="120" y1="15" x2="120" y2="225" stroke="#000" strokeWidth="1.2" />
            <line x1="35" y1="40" x2="205" y2="40" stroke="#000" strokeWidth="1.2" />

            <text x="120" y="10" fontSize="11" fontStyle="italic" fill="#000">y</text>
            <text x="210" y="44" fontSize="11" fontStyle="italic" fill="#000">x</text>

            {/* Line with positive slope */}
            <line x1="90" y1="220" x2="170" y2="20" stroke="#000" strokeWidth="1.8" />

            {/* Numbers */}
            {[-4, -2, 2, 4].map((v) => (
              <text key={v} x={120 + (v / 4) * 80} y="52" textAnchor="middle" fontSize="9" fill="#000">
                {v}
              </text>
            ))}
            {[-2, -4, -6, -8, -10].map((v) => (
              <text key={v} x="114" y={40 - (v / 10) * 160 + 3.5} textAnchor="end" fontSize="9" fill="#000">
                {v}
              </text>
            ))}
          </svg>
        </div>
      );

    default:
      return null;
  }
};
