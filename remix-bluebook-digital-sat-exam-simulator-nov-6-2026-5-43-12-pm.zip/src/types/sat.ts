export type SectionType = 'rw' | 'math';

export interface QuestionOption {
  id: 'A' | 'B' | 'C' | 'D';
  text: string;
}

export interface Question {
  id: number;
  module: 1 | 2;
  section: SectionType;
  promptTitle?: string;
  passage?: string;
  passageTitle?: string;
  questionText: string;
  image?: string; // Optional image / screenshot for the question
  options?: QuestionOption[];
  isSPR?: boolean; // Student-Produced Response (grid-in)
  correctAnswer: string;
  acceptedAnswers?: string[];
  explanation: string;
  domain: string;
  skill: string;
  graphicType?: string;
}

export interface HighlightItem {
  id: string;
  questionId: number;
  text: string;
  color: 'yellow' | 'pink' | 'blue' | 'underline';
  note?: string;
  timestamp: number;
}

export interface QuestionState {
  selectedOption?: 'A' | 'B' | 'C' | 'D';
  sprValue?: string;
  isMarkedForReview: boolean;
  crossedOptions: ('A' | 'B' | 'C' | 'D')[];
  notes?: string;
}

export interface ExamModuleConfig {
  id: string;
  title: string;
  section: SectionType;
  moduleNumber: 1 | 2;
  totalQuestions: number;
  durationSeconds: number;
}
