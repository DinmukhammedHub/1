import React, { useState, useEffect, useRef, useCallback } from 'react';
import { TopBar } from './components/TopBar';
import { BottomBar } from './components/BottomBar';
import { StimulusPane } from './components/StimulusPane';
import { QuestionPane } from './components/QuestionPane';
import { QuestionReviewModal } from './components/QuestionReviewModal';
import { DirectionsModal } from './components/DirectionsModal';
import { DesmosCalculator } from './components/DesmosCalculator';
import { ReferenceSheetModal } from './components/ReferenceSheetModal';
import { HighlightsDrawer } from './components/HighlightsDrawer';
import { ModuleEndReview } from './components/ModuleEndReview';
import { BreakScreen } from './components/BreakScreen';
import { ScoreReportModal } from './components/ScoreReportModal';
import { SectionIntroScreen } from './components/SectionIntroScreen';
import { FullscreenImageModal } from './components/FullscreenImageModal';
import { 
  mockQuestionsRW1, 
  mockQuestionsRW2, 
  mockQuestionsMath1, 
  mockQuestionsMath2 
} from './data/mockQuestions';
import { Question, QuestionState, HighlightItem, SectionType } from './types/sat';

export default function App() {
  const [sectionType, setSectionType] = useState<SectionType>('rw');
  const [moduleNumber, setModuleNumber] = useState<1 | 2>(2);
  // Default to Question 1 of Reading and Writing Module 2 (Hard)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);

  // Student name matching Bluebook test candidate
  const [studentName, setStudentName] = useState<string>('Dinmukhammed Sattar');

  // Timer: 11:45 (705 seconds) matching the uploaded Bluebook screenshot
  const [timeRemainingSeconds, setTimeRemainingSeconds] = useState<number>(705);
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(true);
  const [isTimerHidden, setIsTimerHidden] = useState<boolean>(false);

  // Question answer states across all 4 exam modules
  const [rw1QuestionStates, setRw1QuestionStates] = useState<Record<number, QuestionState>>({});
  const [rw2QuestionStates, setRw2QuestionStates] = useState<Record<number, QuestionState>>({
    0: { selectedOption: 'C', crossedOptions: [], isMarkedForReview: false },
  });
  const [math1QuestionStates, setMath1QuestionStates] = useState<Record<number, QuestionState>>({});
  const [math2QuestionStates, setMath2QuestionStates] = useState<Record<number, QuestionState>>({});

  const [highlights, setHighlights] = useState<HighlightItem[]>([]);

  // Split Pane Resizer (default exactly 50% left, 50% right matching screenshot)
  const [leftPanePercent, setLeftPanePercent] = useState<number>(50);
  const isDraggingDividerRef = useRef(false);

  // Tools & Display
  const [isLineReaderActive, setIsLineReaderActive] = useState<boolean>(false);
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xlarge'>('normal');

  // Modals & Navigation
  const [isReviewGridOpen, setIsReviewGridOpen] = useState<boolean>(false);
  const [isDirectionsOpen, setIsDirectionsOpen] = useState<boolean>(false);
  const [isCalculatorOpen, setIsCalculatorOpen] = useState<boolean>(false);
  const [isReferenceOpen, setIsReferenceOpen] = useState<boolean>(false);
  const [isHighlightsDrawerOpen, setIsHighlightsDrawerOpen] = useState<boolean>(false);
  const [isModuleEndReviewOpen, setIsModuleEndReviewOpen] = useState<boolean>(false);
  const [isOnBreak, setIsOnBreak] = useState<boolean>(false);
  const [isSectionIntroOpen, setIsSectionIntroOpen] = useState<boolean>(false);
  const [isScoreReportOpen, setIsScoreReportOpen] = useState<boolean>(false);
  const [isFullscreenImageModalOpen, setIsFullscreenImageModalOpen] = useState<boolean>(false);
  const [activePhotoIndex, setActivePhotoIndex] = useState<number>(0);

  // Current questions list
  const currentQuestions: Question[] = 
    sectionType === 'rw' 
      ? (moduleNumber === 1 ? mockQuestionsRW1 : mockQuestionsRW2)
      : (moduleNumber === 1 ? mockQuestionsMath1 : mockQuestionsMath2);

  const currentQuestion = currentQuestions[currentQuestionIndex] || currentQuestions[0];

  const currentQuestionStates = 
    sectionType === 'rw'
      ? (moduleNumber === 1 ? rw1QuestionStates : rw2QuestionStates)
      : (moduleNumber === 1 ? math1QuestionStates : math2QuestionStates);

  const setQuestionStates = 
    sectionType === 'rw'
      ? (moduleNumber === 1 ? setRw1QuestionStates : setRw2QuestionStates)
      : (moduleNumber === 1 ? setMath1QuestionStates : setMath2QuestionStates);

  // Real-time countdown timer
  useEffect(() => {
    if (isOnBreak || isScoreReportOpen || !isTimerRunning) return;

    const timer = setInterval(() => {
      setTimeRemainingSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setIsModuleEndReviewOpen(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOnBreak, isScoreReportOpen, isTimerRunning]);

  // Handle Dragging Divider Resizer
  const handleDividerMouseDown = useCallback(() => {
    isDraggingDividerRef.current = true;
    document.body.style.cursor = 'col-resize';
  }, []);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isDraggingDividerRef.current) return;
    const windowWidth = window.innerWidth;
    const newPercent = (e.clientX / windowWidth) * 100;
    if (newPercent >= 28 && newPercent <= 72) {
      setLeftPanePercent(newPercent);
    }
  }, []);

  const handleMouseUp = useCallback(() => {
    isDraggingDividerRef.current = false;
    document.body.style.cursor = '';
  }, []);

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);

  const handleSelectOption = (optionId: 'A' | 'B' | 'C' | 'D') => {
    setQuestionStates((prev) => {
      const currentState = prev[currentQuestionIndex] || {
        isMarkedForReview: false,
        crossedOptions: [],
      };
      const newSelected = currentState.selectedOption === optionId ? undefined : optionId;
      const newCrossed = currentState.crossedOptions.filter((id) => id !== optionId);

      return {
        ...prev,
        [currentQuestionIndex]: {
          ...currentState,
          selectedOption: newSelected,
          crossedOptions: newCrossed,
        },
      };
    });
  };

  const handleToggleCrossOption = (optionId: 'A' | 'B' | 'C' | 'D') => {
    setQuestionStates((prev) => {
      const currentState = prev[currentQuestionIndex] || {
        isMarkedForReview: false,
        crossedOptions: [],
      };
      const isAlreadyCrossed = currentState.crossedOptions.includes(optionId);
      const newCrossed = isAlreadyCrossed
        ? currentState.crossedOptions.filter((id) => id !== optionId)
        : [...currentState.crossedOptions, optionId];

      const newSelected = currentState.selectedOption === optionId ? undefined : currentState.selectedOption;

      return {
        ...prev,
        [currentQuestionIndex]: {
          ...currentState,
          crossedOptions: newCrossed,
          selectedOption: newSelected,
        },
      };
    });
  };

  const handleToggleMarkForReview = () => {
    setQuestionStates((prev) => {
      const currentState = prev[currentQuestionIndex] || {
        isMarkedForReview: false,
        crossedOptions: [],
      };
      return {
        ...prev,
        [currentQuestionIndex]: {
          ...currentState,
          isMarkedForReview: !currentState.isMarkedForReview,
        },
      };
    });
  };

  const handleUpdateSPR = (val: string) => {
    setQuestionStates((prev) => {
      const currentState = prev[currentQuestionIndex] || {
        isMarkedForReview: false,
        crossedOptions: [],
      };
      return {
        ...prev,
        [currentQuestionIndex]: {
          ...currentState,
          sprValue: val,
        },
      };
    });
  };

  const handleAddHighlight = (item: Omit<HighlightItem, 'id' | 'timestamp'>) => {
    const newHighlight: HighlightItem = {
      ...item,
      id: Math.random().toString(36).substring(2, 9),
      timestamp: Date.now(),
    };
    setHighlights((prev) => [...prev, newHighlight]);
  };

  const handleRemoveHighlight = (id: string) => {
    setHighlights((prev) => prev.filter((h) => h.id !== id));
  };

  const handlePrevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex((prev) => prev - 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < currentQuestions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else {
      setIsModuleEndReviewOpen(true);
    }
  };

  const handleSubmitModule = () => {
    setIsModuleEndReviewOpen(false);
    if (sectionType === 'rw' && moduleNumber === 1) {
      setSectionType('rw');
      setModuleNumber(2);
      setCurrentQuestionIndex(0);
      setTimeRemainingSeconds(1920); // 32 minutes for RW Module 2 (Hard)
      setIsSectionIntroOpen(true);
    } else if (sectionType === 'rw' && moduleNumber === 2) {
      setIsOnBreak(true); // Official 10-minute break between sections!
    } else if (sectionType === 'math' && moduleNumber === 1) {
      setSectionType('math');
      setModuleNumber(2);
      setCurrentQuestionIndex(0);
      setTimeRemainingSeconds(2100); // 35 minutes for Math Module 2 (Hard)
      setIsSectionIntroOpen(true);
    } else {
      setIsScoreReportOpen(true);
    }
  };

  const handleResumeFromBreak = () => {
    setIsOnBreak(false);
    setSectionType('math');
    setModuleNumber(1);
    setCurrentQuestionIndex(0);
    setTimeRemainingSeconds(2100); // 35 minutes for Math Module 1
    setIsSectionIntroOpen(true);
  };

  const handleBeginSection = () => {
    setIsSectionIntroOpen(false);
    setIsTimerRunning(true);
  };

  const handleResetTest = () => {
    setSectionType('rw');
    setModuleNumber(1);
    setCurrentQuestionIndex(0);
    setTimeRemainingSeconds(1920);
    setRw1QuestionStates({});
    setRw2QuestionStates({});
    setMath1QuestionStates({});
    setMath2QuestionStates({});
    setHighlights([]);
  };

  const handleSwitchSection = (sec: SectionType, mod: 1 | 2 = 1) => {
    setSectionType(sec);
    setModuleNumber(mod);
    setCurrentQuestionIndex(0);
    setTimeRemainingSeconds(sec === 'rw' ? 1920 : 2100);
  };

  const sectionTitle = sectionType === 'rw'
    ? `Section 1, Module ${moduleNumber}: Reading and Writing`
    : `Section 2, Module ${moduleNumber}: Math`;

  if (isOnBreak) {
    return <BreakScreen onResumeTest={handleResumeFromBreak} studentName={studentName} />;
  }

  if (isSectionIntroOpen) {
    return (
      <SectionIntroScreen
        sectionType={sectionType}
        moduleNumber={moduleNumber}
        studentName={studentName}
        onBegin={handleBeginSection}
      />
    );
  }

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-white text-slate-900 select-none">
      {/* 1:1 Pixel Perfect Top Bar */}
      <TopBar
        sectionTitle={sectionTitle}
        moduleNumber={moduleNumber}
        sectionType={sectionType}
        timeRemainingSeconds={timeRemainingSeconds}
        isTimerRunning={isTimerRunning}
        onToggleTimerRunning={() => setIsTimerRunning(!isTimerRunning)}
        isTimerHidden={isTimerHidden}
        onToggleTimerHidden={() => {
          if (timeRemainingSeconds > 300) {
            setIsTimerHidden(!isTimerHidden);
          }
        }}
        onResetTimer={() => setTimeRemainingSeconds(sectionType === 'rw' ? 1920 : 2100)}
        onSetTimeRemainingSeconds={setTimeRemainingSeconds}
        defaultModuleSeconds={sectionType === 'rw' ? 1920 : 2100}
        onOpenDirections={() => setIsDirectionsOpen(true)}
        onOpenHighlights={() => setIsHighlightsDrawerOpen(true)}
        onOpenCalculator={() => setIsCalculatorOpen(true)}
        onOpenReference={() => setIsReferenceOpen(true)}
        onToggleLineReader={() => setIsLineReaderActive(!isLineReaderActive)}
        isLineReaderActive={isLineReaderActive}
        fontSize={fontSize}
        onChangeFontSize={setFontSize}
        onSwitchSection={handleSwitchSection}
        onOpenBreakScreen={() => setIsOnBreak(true)}
        onOpenSectionIntro={() => setIsSectionIntroOpen(true)}
        onOpenFullscreenMock={(idx) => {
          setActivePhotoIndex(idx ?? 0);
          setIsFullscreenImageModalOpen(true);
        }}
      />

      {/* Main Examination Viewport */}
      <main className="flex-1 flex overflow-hidden relative">
        {isModuleEndReviewOpen ? (
          <ModuleEndReview
            moduleTitle={sectionTitle}
            totalQuestions={currentQuestions.length}
            currentQuestionIndex={currentQuestionIndex}
            questionStates={currentQuestionStates}
            onSelectQuestion={(idx) => {
              setCurrentQuestionIndex(idx);
              setIsModuleEndReviewOpen(false);
            }}
            onSubmitModule={handleSubmitModule}
            onBackToCurrentQuestion={() => setIsModuleEndReviewOpen(false)}
            studentName={studentName}
          />
        ) : sectionType === 'rw' || currentQuestion.passage ? (
          /* Split Screen View: Left Stimulus / Right Question (Reading & Writing standard) */
          <div className="w-full h-full flex flex-col md:flex-row relative">
            {/* Left Pane: Stimulus / Passage */}
            <div
              style={{ width: `${leftPanePercent}%` }}
              className="h-full overflow-hidden relative"
            >
              <StimulusPane
                passage={currentQuestion.passage}
                passageTitle={currentQuestion.passageTitle}
                questionId={currentQuestion.id}
                graphicType={currentQuestion.graphicType}
                highlights={highlights}
                onAddHighlight={handleAddHighlight}
                onRemoveHighlight={handleRemoveHighlight}
                isLineReaderActive={isLineReaderActive}
                fontSize={fontSize}
              />
            </div>

            {/* Draggable Vertical Divider with Exact Up/Down Triangle Pill Handle */}
            <div
              onMouseDown={handleDividerMouseDown}
              className="group hidden md:flex items-center justify-center w-3 -ml-1.5 cursor-col-resize z-20 relative select-none"
              title="Drag to resize panels"
            >
              {/* Grey vertical divider line */}
              <div className="w-[3px] h-full bg-[#8c96a4] group-hover:bg-blue-600 transition-colors" />

              {/* Black rectangular badge with up and down white arrows matching screenshot */}
              <div className="absolute top-1/2 -translate-y-1/2 w-4 h-9 bg-black text-white rounded-[3px] shadow-sm flex flex-col items-center justify-center gap-1">
                <div className="w-0 h-0 border-l-[3.5px] border-l-transparent border-r-[3.5px] border-r-transparent border-b-[4px] border-b-white" />
                <div className="w-0 h-0 border-l-[3.5px] border-l-transparent border-r-[3.5px] border-r-transparent border-t-[4px] border-t-white" />
              </div>
            </div>

            {/* Right Pane: Question & Choices */}
            <div
              style={{ width: `${100 - leftPanePercent}%` }}
              className="h-full flex-1 overflow-hidden"
            >
              <QuestionPane
                question={currentQuestion}
                questionNumber={currentQuestionIndex + 1}
                questionState={currentQuestionStates[currentQuestionIndex] || {
                  isMarkedForReview: false,
                  crossedOptions: [],
                }}
                onSelectOption={handleSelectOption}
                onToggleCrossOption={handleToggleCrossOption}
                onToggleMarkForReview={handleToggleMarkForReview}
                onUpdateSPR={handleUpdateSPR}
                fontSize={fontSize}
              />
            </div>
          </div>
        ) : (
          /* Single Column Centered Layout: Authentic Bluebook Math Style */
          <div className="w-full h-full flex justify-center overflow-hidden bg-white">
            <div className="w-full max-w-3xl h-full">
              <QuestionPane
                question={currentQuestion}
                questionNumber={currentQuestionIndex + 1}
                questionState={currentQuestionStates[currentQuestionIndex] || {
                  isMarkedForReview: false,
                  crossedOptions: [],
                }}
                onSelectOption={handleSelectOption}
                onToggleCrossOption={handleToggleCrossOption}
                onToggleMarkForReview={handleToggleMarkForReview}
                onUpdateSPR={handleUpdateSPR}
                fontSize={fontSize}
              />
            </div>
          </div>
        )}
      </main>

      {/* Bottom Bar: Candidate Name, Question Review Navigator, Back / Next */}
      <BottomBar
        currentQuestionIndex={currentQuestionIndex}
        totalQuestions={currentQuestions.length}
        studentName={studentName}
        onUpdateStudentName={setStudentName}
        onPrevQuestion={handlePrevQuestion}
        onNextQuestion={handleNextQuestion}
        onOpenReviewGrid={() => setIsReviewGridOpen(true)}
        isLastQuestion={currentQuestionIndex === currentQuestions.length - 1}
      />

      {/* Modals & Drawers */}
      <QuestionReviewModal
        isOpen={isReviewGridOpen}
        onClose={() => setIsReviewGridOpen(false)}
        totalQuestions={currentQuestions.length}
        currentQuestionIndex={currentQuestionIndex}
        questionStates={currentQuestionStates}
        onSelectQuestion={(idx) => {
          setCurrentQuestionIndex(idx);
          setIsModuleEndReviewOpen(false);
        }}
        onGoToReviewPage={() => setIsModuleEndReviewOpen(true)}
        sectionTitle={sectionTitle}
      />

      <DirectionsModal
        isOpen={isDirectionsOpen}
        onClose={() => setIsDirectionsOpen(false)}
        sectionType={sectionType}
        moduleNumber={moduleNumber}
      />

      <DesmosCalculator
        isOpen={isCalculatorOpen}
        onClose={() => setIsCalculatorOpen(false)}
      />

      <ReferenceSheetModal
        isOpen={isReferenceOpen}
        onClose={() => setIsReferenceOpen(false)}
      />

      <HighlightsDrawer
        isOpen={isHighlightsDrawerOpen}
        onClose={() => setIsHighlightsDrawerOpen(false)}
        highlights={highlights}
        onRemoveHighlight={handleRemoveHighlight}
        onJumpToQuestion={(qid) => {
          const idx = currentQuestions.findIndex((q) => q.id === qid);
          if (idx !== -1) setCurrentQuestionIndex(idx);
        }}
      />

      <ScoreReportModal
        isOpen={isScoreReportOpen}
        onClose={() => setIsScoreReportOpen(false)}
        rw1Questions={mockQuestionsRW1}
        rw1States={rw1QuestionStates}
        rw2Questions={mockQuestionsRW2}
        rw2States={rw2QuestionStates}
        math1Questions={mockQuestionsMath1}
        math1States={math1QuestionStates}
        math2Questions={mockQuestionsMath2}
        math2States={math2QuestionStates}
        onResetTest={handleResetTest}
        studentName={studentName}
      />

      <FullscreenImageModal
        isOpen={isFullscreenImageModalOpen}
        onClose={() => setIsFullscreenImageModalOpen(false)}
        activePhotoIndex={activePhotoIndex}
        onSelectPhotoIndex={setActivePhotoIndex}
      />
    </div>
  );
}
