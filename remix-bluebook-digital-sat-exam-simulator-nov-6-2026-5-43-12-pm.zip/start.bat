@echo off
chcp 65001 >nul
title Bluebook Digital SAT Simulator
color 0b
echo ===================================================
echo     Bluebook Digital SAT Exam Simulator
echo ===================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ОШИБКА] Node.js не установлен на вашем компьютере.
    echo.
    echo Чтобы запускать проект локально, установите Node.js с официального сайта:
    echo https://nodejs.org/
    echo.
    echo Либо просто откройте онлайн версию прямо в браузере:
    echo https://ais-pre-yucpwe5ybx62t5msc4c5f3-583144849249.asia-east1.run.app
    echo.
    pause
    exit /b
)

if not exist node_modules (
    echo [1/2] Установка необходимых пакетов (npm install)...
    call npm install
    if %errorlevel% neq 0 (
        echo [ОШИБКА] Ошибка при установке зависимостей.
        pause
        exit /b
    )
)

echo [2/2] Запуск локального сервера (порт 3000)...
echo Симулятор откроется в браузере автоматически!
echo.

start "" http://localhost:3000
call npm run dev
pause
